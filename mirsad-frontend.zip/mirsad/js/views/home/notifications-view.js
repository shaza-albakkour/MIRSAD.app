M.views.notifications = {
  render: function () {
    const list = M.services.notifications.list(), C = M.components;
    const body = list.length ? list.map(function (n) {
      return '<a class="list-row' + (n.read ? '' : ' is-unread') + '" href="#' + n.link + '">' +
        '<span class="list-row__icon">' + C.icon('bell', 20) + '</span><span class="list-row__text"><strong>' +
        M.core.dom.esc(n.title) + '</strong><small>' + M.core.dom.esc(n.body) + '</small><small>' +
        M.utils.format.time(n.at) + '</small></span></a>';
    }).join('') : C.state.empty('لا توجد إشعارات بعد', 'bell');
    return C.header({ title: 'الإشعارات', back: '/home' }) + '<div class="page">' + body + '</div>';
  },
  mount: function () { M.services.notifications.markAllRead(); }
};
