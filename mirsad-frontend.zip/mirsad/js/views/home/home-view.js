M.views.home = {
  render: function () {
    const me = M.services.auth.current(), C = M.components, unread = M.services.notifications.unread();
    const next = M.services.tickets.list().filter(function (t) { return !M.services.tickets.isPast(t); }).pop();
    return '<section class="home"><header class="home__head">' +
      '<div><small class="muted">' + M.utils.format.date(new Date()) + '</small>' +
      '<h1>' + M.core.dom.esc(M.utils.greeting(me.name)) + '</h1></div>' +
      '<a class="icon-btn" href="#/notifications" aria-label="الإشعارات">' + C.icon('bell', 24) +
      (unread ? '<i class="dot"></i>' : '') + '</a></header>' +
      '<p class="muted">إلى أين تريد الذهاب اليوم؟</p>' +
      C.cards.hero({ tone: 'teal', icon: 'bus', to: '/internal/map', title: 'النقل الداخلي – الزاجل', text: 'للتنقل ضمن محافظة إدلب' }) +
      C.cards.hero({ tone: 'navy', icon: 'route', to: '/external', title: 'النقل الخارجي – بين المحافظات', text: 'للسفر من محافظة سورية إلى أخرى' }) +
      (next ? C.cards.row({ icon: 'ticket', to: '/tickets/' + next.id, title: 'رحلتك القادمة',
        text: M.utils.format.date(next.departure) + ' – ' + M.utils.format.time(next.departure) }) : '') +
      C.cards.row({ icon: 'message', to: '/complaints', title: 'الشكاوى والدعم', text: 'قدّم شكوى أو تابع حالتها' }) +
      '</section>';
  }
};
