M.files('js/views', [
  'auth/auth-layout.js', 'auth/login-view.js', 'auth/login-actions.js',
  'auth/register-view.js', 'auth/register-actions.js', 'auth/otp-view.js', 'auth/otp-actions.js',
  'auth/forgot-view.js', 'auth/forgot-actions.js',
  'home/home-view.js', 'home/notifications-view.js',
  'internal/internal-view.js', 'internal/internal-map.js', 'internal/map-controller.js',
  'internal/internal-stops.js', 'internal/internal-nearby.js', 'internal/internal-alerts.js',
  'internal/alerts-actions.js', 'internal/schedule-form.js', 'internal/stop-detail.js',
  'internal/waiting-sheet.js',
  'external/search-view.js', 'external/search-actions.js', 'external/results-view.js',
  'external/seats-view.js', 'external/seats-actions.js', 'external/checkout-view.js',
  'external/checkout-actions.js',
  'tickets/tickets-view.js', 'tickets/ticket-view.js', 'tickets/ticket-card.js',
  'complaints/complaints-view.js', 'complaints/complaint-new.js', 'complaints/complaint-detail.js',
  'profile/profile-view.js', 'profile/profile-actions.js', 'profile/profile-page.js',
  'profile/page-edit.js', 'profile/page-notifications.js', 'profile/page-location.js',
  'profile/page-favorites.js', 'profile/page-history.js'
]);
