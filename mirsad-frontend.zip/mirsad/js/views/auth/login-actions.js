M.views.login.mount = function (root) {
  const F = M.components.field;
  root.querySelector('#login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    F.clearErrors(root);
    const btn = root.querySelector('button[type=submit]');
    M.components.busy(btn, async function () {
      const r = await M.services.auth.login(M.core.dom.val('phone', root), M.core.dom.val('password', root));
      if (!r.ok) return F.showError(root, r.error.indexOf('كلمة') >= 0 ? 'password' : 'phone', r.error);
      M.core.router.go('/home');
    });
  });
};
