M.views.otp = {
  render: function () {
    const p = M.services.signup.pending();
    if (!p) return M.views.authLayout('انتهت الجلسة', 'ابدأ التسجيل من جديد', '<a class="btn btn--block" href="#/register">رجوع</a>');
    const demo = M.core.store.get('otp-demo', null);
    return M.views.authLayout('التحقق من رقمك', 'أدخل الرمز المكوّن من 6 أرقام المرسل إلى ' + p.phone,
      (demo ? '<div class="demo-banner">' + M.components.icon('info', 16) +
        '<span>لا يوجد مزوّد رسائل مرتبط بعد. الرمز التجريبي: <b>' + demo + '</b></span></div>' : '') +
      '<form id="otp-form" novalidate>' +
      M.components.field({ id: 'code', label: 'رمز التحقق', icon: 'lock', mode: 'numeric', max: 6, auto: 'one-time-code' }) +
      '<button class="btn btn--block" type="submit">تأكيد</button></form>' +
      '<p class="auth__links"><button class="link" id="resend">إعادة إرسال الرمز</button>' +
      '<a href="#/register">تغيير الرقم</a></p>');
  }
};
