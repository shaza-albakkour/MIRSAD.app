M.views.forgot.mount = function (root) {
  const F = M.components.field, v = function (id) { return M.core.dom.val(id, root); };
  let phone = null;
  root.querySelector('#forgot-form').addEventListener('submit', function (e) {
    e.preventDefault();
    F.clearErrors(root);
    M.components.busy(root.querySelector('button[type=submit]'), async function () {
      if (!phone) {
        const r = await M.services.password.start(v('phone'));
        if (!r.ok) return F.showError(root, 'phone', r.error);
        phone = r.phone;
        root.querySelector('#reset-step').hidden = false;
        root.querySelector('#reset-demo').hidden = !r.demoCode;
        root.querySelector('#reset-demo').textContent = 'الرمز التجريبي (لا يوجد مزوّد SMS): ' + r.demoCode;
        root.querySelector('button[type=submit]').dataset.label = 'تغيير كلمة المرور';
        return;
      }
      const r = await M.services.password.finish(phone, v('code'), v('password'));
      if (!r.ok) return F.showError(root, 'password', r.error);
      M.components.toast.show('تم تغيير كلمة المرور، سجّل الدخول', 'success');
      M.core.router.go('/login');
    });
  });
};
