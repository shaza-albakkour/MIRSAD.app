/* قالب مشترك لصفحات الدخول والتسجيل */
M.views.authLayout = function (title, sub, body) {
  return '<section class="auth">' +
    '<img class="auth__logo" src="assets/images/logo.svg" alt="مِرصاد">' +
    '<h2>' + title + '</h2><p class="muted">' + sub + '</p>' + body +
    M.components.demoBanner('backend', 'وضع تجريبي: الحسابات محفوظة على جهازك فقط حتى ربط الخادم.') +
    '</section>';
};
