M.views.register = {
  render: function () {
    const f = M.components.field;
    return M.views.authLayout('إنشاء حساب', 'سجّل لتتبع الباصات وحجز رحلاتك',
      '<form id="register-form" novalidate>' +
      f({ id: 'name', label: 'الاسم الذي نخاطبك به', icon: 'user', auto: 'given-name', placeholder: 'مثال: شذى' }) +
      f({ id: 'phone', label: 'رقم الهاتف السوري', icon: 'phone', type: 'tel', mode: 'tel', auto: 'tel', placeholder: '09XXXXXXXX' }) +
      f({ id: 'password', label: 'كلمة المرور', icon: 'lock', type: 'password', auto: 'new-password', placeholder: '8 أحرف على الأقل' }) +
      f({ id: 'confirm', label: 'تأكيد كلمة المرور', icon: 'lock', type: 'password', auto: 'new-password' }) +
      '<button class="btn btn--block" type="submit">متابعة والتحقق من الرقم</button></form>' +
      '<p class="auth__links"><a href="#/login">لديّ حساب بالفعل</a></p>');
  }
};
