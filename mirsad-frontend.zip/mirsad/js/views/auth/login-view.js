M.views.login = {
  render: function () {
    const f = M.components.field;
    return M.views.authLayout('تسجيل الدخول', 'مرحباً بعودتك إلى مِرصاد',
      '<form id="login-form" novalidate>' +
      f({ id: 'phone', label: 'رقم الهاتف', icon: 'phone', type: 'tel', mode: 'tel', auto: 'tel', placeholder: '09XXXXXXXX' }) +
      f({ id: 'password', label: 'كلمة المرور', icon: 'lock', type: 'password', auto: 'current-password' }) +
      '<button class="btn btn--block" type="submit">دخول</button></form>' +
      '<p class="auth__links"><a href="#/forgot">نسيت كلمة المرور؟</a>' +
      '<a href="#/register">إنشاء حساب جديد</a></p>');
  }
};
