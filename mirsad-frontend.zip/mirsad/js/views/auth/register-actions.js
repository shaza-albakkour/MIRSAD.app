M.views.register.mount = function (root) {
  const F = M.components.field, v = function (id) { return M.core.dom.val(id, root); };
  root.querySelector('#register-form').addEventListener('submit', function (e) {
    e.preventDefault();
    F.clearErrors(root);
    M.components.busy(root.querySelector('button[type=submit]'), async function () {
      const r = await M.services.signup.start({
        name: v('name'), phone: v('phone'), password: v('password'), confirm: v('confirm')
      });
      if (!r.ok && r.field) return F.showError(root, r.field, r.error);
      if (!r.ok) return M.components.toast.show(r.error, 'error');
      M.core.store.set('otp-demo', r.demoCode || null);
      M.core.router.go('/otp');
    });
  });
};
