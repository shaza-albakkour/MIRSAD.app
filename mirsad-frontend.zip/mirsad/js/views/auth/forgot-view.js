M.views.forgot = {
  render: function () {
    const f = M.components.field;
    return M.views.authLayout('استعادة كلمة المرور', 'سنرسل رمز تحقق إلى رقم هاتفك',
      '<form id="forgot-form" novalidate>' +
      f({ id: 'phone', label: 'رقم الهاتف', icon: 'phone', type: 'tel', mode: 'tel', placeholder: '09XXXXXXXX' }) +
      '<div id="reset-step" hidden>' +
      '<div class="demo-banner" id="reset-demo"></div>' +
      f({ id: 'code', label: 'رمز التحقق', icon: 'lock', mode: 'numeric', max: 6 }) +
      f({ id: 'password', label: 'كلمة المرور الجديدة', icon: 'lock', type: 'password', auto: 'new-password' }) +
      '</div><button class="btn btn--block" type="submit">إرسال الرمز</button></form>' +
      '<p class="auth__links"><a href="#/login">رجوع لتسجيل الدخول</a></p>');
  }
};
