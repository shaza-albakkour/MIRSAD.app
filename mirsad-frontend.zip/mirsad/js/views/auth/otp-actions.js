M.views.otp.mount = function (root) {
  const form = root.querySelector('#otp-form');
  if (!form) return;
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    M.components.field.clearErrors(root);
    M.components.busy(form.querySelector('button'), async function () {
      const r = await M.services.signup.finish(M.core.dom.val('code', root));
      if (!r.ok) return M.components.field.showError(root, 'code', r.error);
      M.core.store.remove('otp-demo');
      M.components.toast.show('تم إنشاء حسابك بنجاح', 'success');
      M.core.router.go('/home');
    });
  });
  root.querySelector('#resend').addEventListener('click', async function () {
    const r = await M.services.otp.send(M.services.signup.pending().phone, 'signup');
    if (!r.ok) return M.components.toast.show(r.error, 'error');
    M.core.store.set('otp-demo', r.demoCode || null);
    M.core.router.render();
  });
};
