M.views.pageHistory = {
  render: function () {
    const C = M.components, past = M.services.tickets.list().filter(M.services.tickets.isPast);
    return C.header({ title: 'سجل الرحلات', back: '/profile' }) + '<div class="page">' +
      (past.length ? past.map(M.views.ticketCard).join('') : C.state.empty('لا توجد رحلات سابقة بعد', 'history')) + '</div>';
  }
};
