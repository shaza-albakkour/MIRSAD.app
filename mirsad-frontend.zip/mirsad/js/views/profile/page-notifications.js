M.views.pageNotifications = {
  render: function () {
    const s = M.services.settings.get(), T = M.views.internalAlerts.toggle.bind(M.views.internalAlerts);
    return M.components.header({ title: 'إعدادات الإشعارات', back: '/profile' }) + '<div class="page"><div class="card">' +
      T('approach', 'اقتراب الباص من موقفي', s.approach) + T('schedule', 'تنبيهات مواعيدي المعتادة', s.schedule) +
      T('booking', 'تأكيدات الحجز والتذاكر', s.booking) + T('complaints', 'ردود الشكاوى', s.complaints) +
      T('push', 'إشعارات المتصفح', s.push) + '</div>' +
      '<button class="btn btn--ghost btn--block" id="ask-perm">السماح بإشعارات المتصفح</button></div>';
  },
  mount: function (root) {
    root.addEventListener('change', function (e) {
      if (e.target.dataset.setting) M.services.settings.set({ [e.target.dataset.setting]: e.target.checked });
    });
    root.querySelector('#ask-perm').onclick = async function () {
      const r = await M.services.notifications.requestPermission();
      M.components.toast.show(r === 'granted' ? 'تم السماح بالإشعارات' : 'لم يتم منح الإذن', r === 'granted' ? 'success' : 'error');
    };
  }
};
