M.views.profile.mount = function (root) {
  root.querySelector('#logout').onclick = async function () {
    const ok = await M.components.modal.confirm({ title: 'تسجيل الخروج؟', text: 'يمكنك الدخول مجدداً بأي وقت.', ok: 'خروج', danger: true });
    if (!ok) return;
    M.services.auth.logout();
    M.core.router.go('/login');
  };
};
