/* موزّع صفحات الحساب الفرعية */
M.views.profilePage = {
  pages: function () {
    return { edit: M.views.pageEdit, notifications: M.views.pageNotifications,
      location: M.views.pageLocation, favorites: M.views.pageFavorites, history: M.views.pageHistory };
  },
  render: function (p) {
    const page = this.pages()[p.page];
    return page ? page.render() : M.components.header({ title: 'غير موجود', back: '/profile' }) + M.components.state.empty('الصفحة غير موجودة');
  },
  mount: function (root, p) {
    const page = this.pages()[p.page];
    if (page && page.mount) page.mount(root);
  }
};
