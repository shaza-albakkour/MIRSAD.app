M.views.profile = {
  render: function () {
    const me = M.services.auth.current(), C = M.components, R = C.cards.row, E = M.core.dom.esc;
    const fresh = M.services.complaints.unreadReplies();
    return C.header({ title: 'حسابي' }) + '<div class="page"><div class="card profile-head"><span class="avatar">' +
      E(me.name.charAt(0)) + '</span><div><strong>' + E(me.name) + '</strong><small>' + me.phone + ' · ' + me.operator + '</small></div></div>' +
      R({ icon: 'edit', to: '/profile/edit', title: 'تعديل المعلومات الشخصية' }) +
      R({ icon: 'ticket', to: '/tickets', title: 'التذاكر الحالية والسابقة' }) +
      R({ icon: 'history', to: '/profile/history', title: 'سجل الرحلات السابقة' }) +
      R({ icon: 'bell', to: '/profile/notifications', title: 'إعدادات الإشعارات' }) +
      R({ icon: 'calendar', to: '/internal/alerts', title: 'مواعيد التنبيهات المجدولة' }) +
      R({ icon: 'star', to: '/profile/favorites', title: 'المواقف المفضلة' }) +
      R({ icon: 'locate', to: '/profile/location', title: 'إعدادات الموقع الجغرافي' }) +
      R({ icon: 'message', to: '/complaints', title: 'الشكاوى', badge: fresh ? '<i class="dot dot--inline"></i>' : '' }) +
      '<button class="btn btn--danger btn--block" id="logout">' + C.icon('logout', 18) + ' تسجيل الخروج</button></div>';
  }
};
