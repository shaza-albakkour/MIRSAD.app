M.views.pageEdit = {
  render: function () {
    const me = M.services.auth.current(), f = M.components.field;
    return M.components.header({ title: 'تعديل المعلومات', back: '/profile' }) + '<form class="page" id="edit-form" novalidate>' +
      f({ id: 'name', label: 'الاسم', icon: 'user', value: me.name }) +
      '<div class="field"><span class="field__label">رقم الهاتف</span><div class="field__box">' + M.components.icon('phone', 18) +
      '<input value="' + me.phone + '" disabled></div><small class="muted">تغيير الرقم يتطلب تحققاً OTP عبر الدعم</small></div>' +
      '<button class="btn btn--block" type="submit">حفظ الاسم</button>' +
      '<h3>تغيير كلمة المرور</h3>' + f({ id: 'old', label: 'الحالية', icon: 'lock', type: 'password' }) +
      f({ id: 'new', label: 'الجديدة (8 أحرف على الأقل)', icon: 'lock', type: 'password' }) +
      '<button class="btn btn--ghost btn--block" type="button" id="pass-btn">تغيير كلمة المرور</button></form>';
  },
  mount: function (root) {
    const v = function (id) { return M.core.dom.val(id, root); };
    root.querySelector('#edit-form').onsubmit = function (e) {
      e.preventDefault();
      if (v('name').length < 2) return M.components.field.showError(root, 'name', 'اكتب اسماً صحيحاً');
      M.services.auth.updateProfile({ name: v('name') });
      M.components.toast.show('تم حفظ التعديلات', 'success');
    };
    root.querySelector('#pass-btn').onclick = function (e) {
      if (v('new').length < 8) return M.components.field.showError(root, 'new', 'كلمة المرور 8 أحرف على الأقل');
      M.components.busy(e.currentTarget, async function () {
        const r = await M.services.auth.changePassword(v('old'), v('new'));
        if (!r.ok) return M.components.field.showError(root, 'old', r.error);
        M.components.toast.show('تم تغيير كلمة المرور', 'success');
      });
    };
  }
};
