M.views.pageLocation = {
  render: function () {
    const C = M.components;
    return C.header({ title: 'إعدادات الموقع', back: '/profile' }) + '<div class="page"><div class="card">' +
      '<p>يحتاج التطبيق موقعك لإظهار أقرب موقف والباصات القريبة والتحقق من طلب الانتظار.</p>' +
      '<div id="loc-status" class="muted">' + C.state.loading('جارٍ الفحص...') + '</div>' +
      '<button class="btn btn--block" id="loc-test">' + C.icon('locate', 18) + ' اختبار تحديد الموقع</button></div>' +
      '<div class="card"><div class="kv"><span>محاكاة موقعي قرب موقف إدلب (للتجربة فقط)</span><label class="switch"><input type="checkbox" id="sim"' +
      (M.services.gps.isSimulated() ? ' checked' : '') + '><span></span></label></div></div></div>';
  },
  mount: function (root) {
    const show = async function () {
      const r = await M.services.gps.get(), box = root.querySelector('#loc-status');
      box.innerHTML = r.ok ? 'تم تحديد الموقع' + (r.simulated ? ' (محاكى)' : '') + ': ' + r.pos.map(function (x) { return x.toFixed(4); }).join('، ') : r.error;
    };
    root.querySelector('#loc-test').onclick = show;
    root.querySelector('#sim').onchange = function (e) { M.services.gps.setSimulated(e.target.checked); show(); };
    show();
  }
};
