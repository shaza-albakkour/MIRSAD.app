M.views.pageFavorites = {
  render: function () {
    const C = M.components, ids = M.services.favorites.list();
    return C.header({ title: 'المواقف المفضلة', back: '/profile' }) + '<div class="page">' +
      (ids.length ? ids.map(function (id) {
        const s = M.data.stop(id);
        return C.cards.row({ icon: 'star', to: '/internal/stop/' + id, title: s.name, text: 'عدد المنتظرين: ' + M.services.waiting.countAt(id) });
      }).join('') : C.state.empty('أضف مواقف من صفحة الموقف بالضغط على النجمة', 'star')) + '</div>';
  }
};
