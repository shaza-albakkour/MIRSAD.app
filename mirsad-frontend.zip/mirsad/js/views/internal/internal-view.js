/* واجهة النقل الداخلي: تبويبات + زر الانتظار */
M.views.internal = {
  tabs: [
    { key: 'map', label: 'الخريطة', to: '/internal/map' },
    { key: 'stops', label: 'المواقف', to: '/internal/stops' },
    { key: 'nearby', label: 'قريبة منك', to: '/internal/nearby' },
    { key: 'alerts', label: 'تنبيهاتي', to: '/internal/alerts' }
  ],
  sub: function (tab) {
    return { map: M.views.internalMap, stops: M.views.internalStops,
      nearby: M.views.internalNearby, alerts: M.views.internalAlerts }[tab] || M.views.internalMap;
  },
  render: function (p) {
    this.active = p.tab;
    return M.components.header({ title: 'النقل الداخلي – الزاجل' }) +
      M.components.tabs(this.tabs, p.tab) +
      M.components.demoBanner('tracking', 'بيانات الباصات تجريبية (محاكاة) وليست مواقع حقيقية.') +
      '<div class="page page--tab" id="tab-body">' + this.sub(p.tab).render() + '</div>' +
      M.components.waitingFab();
  },
  mount: function (root, p) {
    M.views.waitingSheet.bind(root);
    const sub = this.sub(p.tab);
    if (sub.mount) sub.mount(root.querySelector('#tab-body'), p);
  },
  unmount: function () {
    const sub = this.sub(this.active);
    if (sub.unmount) sub.unmount();
  }
};
