M.views.internalNearby = {
  render: function () { return '<h3>باصات قريبة منك</h3><div id="nearby-list">' + M.components.state.loading() + '</div>'; },
  mount: async function (root) {
    const box = root.querySelector('#nearby-list'), loc = await M.services.gps.get();
    if (!loc.ok) { box.innerHTML = M.components.state.error(loc.error); return; }
    const F = M.utils.format;
    const list = M.services.trackingQuery.nearbyBuses(loc.pos, 5);
    box.innerHTML = list.length ? list.map(function (n) {
      return '<div class="card bus-card" style="--c:' + M.data.line(n.bus.line).color + '">' +
        '<div class="bus-card__eta"><b>' + F.minutes(n.minutes) + '</b><small>للموقف</small></div>' +
        '<div class="bus-card__info"><strong>' + n.bus.code + ' · يبعد ' + F.distance(n.distance) + '</strong>' +
        '<span>أقرب موقف لك: ' + n.stop.name + ' (' + F.distance(n.stopDistance) + ')</span>' +
        '<small>يتجه ' + M.utils.geo.compass(n.bus.bearing) + '</small></div></div>';
    }).join('') : M.components.state.empty('لا تتوفر بيانات تتبع حالياً', 'bus');
    this.timer = setTimeout(function () { M.core.router.render(); }, 10000);
  },
  unmount: function () { clearTimeout(this.timer); }
};
