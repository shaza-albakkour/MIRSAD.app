M.views.internalAlerts = {
  toggle: function (key, label, on) {
    return '<div class="kv"><span>' + label + '</span><label class="switch"><input type="checkbox" data-setting="' + key +
      '"' + (on ? ' checked' : '') + '><span></span></label></div>';
  },
  render: function () {
    const s = M.services.settings.get();
    const radii = [0.5, 1, 2, 3].map(function (r) {
      return '<option value="' + r + '"' + (r === s.radiusKm ? ' selected' : '') + '>' + r + ' كم</option>';
    }).join('');
    return '<div class="card"><h3>إشعارات اقتراب الباص</h3>' +
      this.toggle('approach', 'أبلغني عند اقتراب الباص من موقفي', s.approach) +
      '<div class="kv"><span>نطاق الإشعار</span><select class="select select--sm" id="radius">' + radii + '</select></div>' +
      '<button class="btn btn--ghost btn--sm" id="ask-perm">تفعيل إشعارات المتصفح</button>' +
      '<p class="muted small">تعمل التنبيهات أثناء فتح التطبيق. التنبيهات في الخلفية تتطلب ربط خادم Push.</p></div>' +
      '<div class="row row--between"><h3>مواعيدي المعتادة</h3>' +
      '<button class="btn btn--sm" id="add-schedule">' + M.components.icon('plus', 16) + ' إضافة</button></div>' +
      '<div id="schedule-list">' + this.list() + '</div>';
  },
  list: function () {
    const S = M.services.schedules, items = S.list();
    if (!items.length) return M.components.state.empty('لم تضف أي موعد بعد', 'calendar');
    return items.map(function (x) {
      const stop = x.stopId && x.stopId !== 'current' ? M.data.stop(x.stopId).name : 'أقرب موقف لموقعي';
      return '<div class="card schedule" data-id="' + x.id + '"><div><strong>' + S.summary(x) + '</strong>' +
        '<small>' + stop + ' · ' + (x.kind === 'all' ? 'كل الباصات' : 'أقرب باص') + '</small></div>' +
        '<label class="switch"><input type="checkbox" data-sc-toggle' + (x.enabled ? ' checked' : '') + '><span></span></label>' +
        '<button class="icon-btn" data-sc-edit>' + M.components.icon('edit', 18) + '</button>' +
        '<button class="icon-btn" data-sc-del>' + M.components.icon('trash', 18) + '</button></div>';
    }).join('');
  }
};
