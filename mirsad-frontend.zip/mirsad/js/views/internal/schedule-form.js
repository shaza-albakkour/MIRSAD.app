/* نموذج إضافة/تعديل موعد تنبيه */
M.views.scheduleForm = {
  open: function (item, done) {
    const S = M.services.schedules, cur = item || { time: '07:30', days: [0, 1, 2, 3, 4], stopId: 'current', kind: 'nearest' };
    const days = S.dayNames.map(function (n, i) {
      return '<button type="button" class="day' + (cur.days.indexOf(i) >= 0 ? ' is-on' : '') + '" data-day="' + i + '">' + n + '</button>';
    }).join('');
    const stops = [{ id: 'current', name: 'أقرب موقف لموقعي الحالي' }].concat(M.data.stops).map(function (s) {
      return '<option value="' + s.id + '"' + (s.id === cur.stopId ? ' selected' : '') + '>' + s.name + '</option>';
    }).join('');
    const el = M.components.modal.sheet('<h3>' + (item ? 'تعديل الموعد' : 'موعد جديد') + '</h3>' +
      '<label class="field"><span class="field__label">الوقت</span><input class="select" type="time" id="sc-time" value="' + cur.time + '"></label>' +
      '<div class="days">' + days + '</div><label class="field"><span class="field__label">الموقف</span><select class="select" id="sc-stop">' + stops + '</select></label>' +
      '<label class="field"><span class="field__label">نوع الإشعار</span><select class="select" id="sc-kind"><option value="nearest">أقرب باص فقط</option>' +
      '<option value="all"' + (cur.kind === 'all' ? ' selected' : '') + '>كل الباصات القادمة</option></select></label>' +
      '<p class="field__error" id="sc-error"></p><button class="btn btn--block" id="sc-save">حفظ</button>');
    el.addEventListener('click', function (e) {
      const d = e.target.closest('.day');
      if (d) d.classList.toggle('is-on');
    });
    el.querySelector('#sc-save').onclick = function () {
      const r = S.save(Object.assign({}, cur, {
        time: el.querySelector('#sc-time').value, stopId: el.querySelector('#sc-stop').value, kind: el.querySelector('#sc-kind').value,
        days: Array.from(el.querySelectorAll('.day.is-on')).map(function (b) { return Number(b.dataset.day); })
      }));
      if (!r.ok) { el.querySelector('#sc-error').textContent = r.error; return; }
      el.remove(); done();
    };
  }
};
