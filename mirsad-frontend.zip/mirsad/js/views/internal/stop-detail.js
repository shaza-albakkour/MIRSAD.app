M.views.stopDetail = {
  render: function (p) {
    const s = M.data.stop(p.id), C = M.components;
    if (!s) return C.header({ title: 'موقف غير موجود', back: '/internal/stops' }) + C.state.empty('هذا الموقف غير موجود');
    const star = '<button class="icon-btn" id="fav-btn" aria-label="مفضلة">' + C.icon('star', 22) + '</button>';
    return C.header({ title: s.name, back: '/internal/stops', action: star }) +
      C.demoBanner('tracking', 'أوقات الوصول محسوبة من حركة تجريبية وليست من GPS حقيقي.') +
      '<div class="page"><p class="muted">المنتظرون الآن: <b id="wait-count">' + M.services.waiting.countAt(s.id) + '</b></p>' +
      '<div id="arrivals">' + this.arrivals(s.id) + '</div>' +
      '<button class="btn btn--block" id="wait-here">' + C.icon('hand', 20) + ' أنا بانتظار الباص هنا</button></div>';
  },
  arrivals: function (id) {
    const list = M.services.trackingQuery.arrivals(id);
    if (!list.length) return M.components.state.empty('لا تتوفر بيانات تتبع لهذا الموقف حالياً', 'bus');
    const q = M.services.trackingQuery, F = M.utils.format, seen = {};
    return list.map(M.components.busCard).join('') + '<h3>الرحلات التالية</h3><div class="card">' +
      list.map(function (a) {
        const gap = seen[a.line.id] ? '' : '<small>كل ' + Math.round(q.headway(a.line.id)) + ' دقيقة تقريباً</small>';
        seen[a.line.id] = 1;
        return '<div class="kv"><span>' + a.bus.code + '</span><b>' + F.time(Date.now() + (a.minutes + a.loop) * 60000) + '</b>' + gap + '</div>';
      }).join('') + '</div>';
  },
  mount: function (root, p) {
    const self = this, id = p.id, fav = root.querySelector('#fav-btn');
    if (!fav) return;
    fav.classList.toggle('is-on', M.services.favorites.has(id));
    fav.onclick = function () { fav.classList.toggle('is-on', M.services.favorites.toggle(id)); };
    root.querySelector('#wait-here').onclick = function () { M.views.waitingSheet.open(id); };
    this.timer = setInterval(function () {
      root.querySelector('#arrivals').innerHTML = self.arrivals(id);
    }, 5000);
  },
  unmount: function () { clearInterval(this.timer); }
};
