/* منطق الخريطة: الطبقات، تحديث الباصات كل ثانيتين، أقرب موقف */
M.views.mapController = {
  timer: null, map: null,
  start: function (root) {
    const self = this, L_ = M.services.mapLayers, markers = {}, ref = {};
    this.map = M.services.map.create(root.querySelector('#map'));
    if (this.map) {
      L_.lines(this.map);
      L_.stops(this.map, function (s) { M.core.router.go('/internal/stop/' + s.id); });
      L_.buses(this.map, markers);
      this.timer = setInterval(function () { L_.buses(self.map, markers); }, 2000);
    }
    const locate = async function (fly) {
      const card = root.querySelector('#nearest-card'), loc = await M.services.gps.get();
      if (!loc.ok) { card.innerHTML = M.components.state.error(loc.error, 'retry-loc'); return; }
      if (self.map) { L_.user(self.map, loc.pos, ref); if (fly) self.map.setView(loc.pos, 15); }
      const n = M.services.trackingQuery.nearestStop(loc.pos);
      card.innerHTML = '<strong>أقرب موقف: ' + n.stop.name + '</strong><p class="muted">يبعد ' +
        M.utils.format.distance(n.distance) + ' عنك</p><a class="btn btn--sm" href="#/internal/stop/' + n.stop.id + '">مواعيد الباصات</a>';
    };
    root.addEventListener('click', function (e) {
      if (e.target.closest('#map-locate') || e.target.closest('#retry-loc')) locate(true);
    });
    locate(false);
  },
  stop: function () {
    clearInterval(this.timer);
    if (this.map) { this.map.remove(); this.map = null; }
  }
};
