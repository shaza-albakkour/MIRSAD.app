/* نافذة «أنا بانتظار الباص»: إرسال الطلب أو عرضه وإلغاؤه */
M.views.waitingSheet = {
  bind: function (root) {
    const self = this;
    root.addEventListener('click', function (e) {
      if (e.target.closest('#waiting-fab')) self.open();
    });
  },
  open: async function (stopId) {
    const mine = M.services.waiting.mine();
    if (mine) return this.showActive(mine);
    const loc = await M.services.gps.get();
    const def = stopId || (loc.ok ? M.services.trackingQuery.nearestStop(loc.pos).stop.id : M.data.stops[0].id);
    const opts = M.data.stops.map(function (s) {
      return '<option value="' + s.id + '"' + (s.id === def ? ' selected' : '') + '>' + s.name + '</option>';
    }).join('');
    const cfg = M.config.app.waiting;
    const el = M.components.modal.sheet('<h3>أنا بانتظار الباص</h3>' +
      '<p class="muted">سنتحقق من وجودك قرب الموقف (ضمن ' + cfg.radiusMeters + ' م) ثم نبلّغ السائق. تنتهي صلاحية الطلب بعد ' + cfg.ttlMinutes + ' دقيقة.</p>' +
      '<select id="wait-stop" class="select">' + opts + '</select>' +
      (loc.ok ? '' : '<p class="field__error">' + loc.error + '</p>') +
      '<button class="btn btn--block" id="wait-send">إرسال طلب الانتظار</button>');
    el.querySelector('#wait-send').onclick = function (e) {
      M.components.busy(e.currentTarget, async function () {
        const r = await M.services.waiting.request(el.querySelector('#wait-stop').value);
        if (!r.ok) return M.components.toast.show(r.error, 'error');
        el.remove();
        M.components.toast.show('تم إبلاغ السائق بوجودك في الموقف', 'success');
        M.core.router.render();
      });
    };
  },
  showActive: function (r) {
    const el = M.components.modal.sheet('<h3>طلب الانتظار فعّال</h3><p>' + M.data.stop(r.stopId).name +
      '</p><p class="muted">ينتهي ' + M.utils.format.time(r.expiresAt) + '</p>' +
      '<button class="btn btn--danger btn--block" id="wait-cancel">إلغاء الطلب (ركبت الباص أو غادرت)</button>');
    el.querySelector('#wait-cancel').onclick = function () {
      M.services.waiting.cancel(); el.remove(); M.core.router.render();
    };
  }
};
