M.views.internalAlerts.mount = function (root) {
  const self = this, S = M.services.schedules, refresh = function () {
    root.querySelector('#schedule-list').innerHTML = self.list();
  };
  root.addEventListener('change', function (e) {
    const t = e.target;
    if (t.dataset.setting) M.services.settings.set({ [t.dataset.setting]: t.checked });
    if (t.id === 'radius') M.services.settings.set({ radiusKm: Number(t.value) });
    if (t.hasAttribute('data-sc-toggle')) S.toggle(t.closest('.schedule').dataset.id);
  });
  root.addEventListener('click', async function (e) {
    const row = e.target.closest('.schedule');
    if (e.target.closest('#add-schedule')) M.views.scheduleForm.open(null, refresh);
    if (e.target.closest('[data-sc-edit]')) M.views.scheduleForm.open(S.get(row.dataset.id), refresh);
    if (e.target.closest('[data-sc-del]') &&
      await M.components.modal.confirm({ title: 'حذف الموعد؟', text: 'لن تصلك تنبيهات هذا الموعد بعد الآن.', ok: 'حذف', danger: true })) {
      S.remove(row.dataset.id); refresh();
    }
    if (e.target.closest('#ask-perm')) {
      const r = await M.services.notifications.requestPermission();
      M.components.toast.show(r === 'granted' ? 'تم تفعيل إشعارات المتصفح' : 'لم يتم منح إذن الإشعارات', r === 'granted' ? 'success' : 'error');
    }
  });
};
