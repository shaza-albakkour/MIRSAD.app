M.views.internalMap = {
  render: function () {
    return '<div class="map-wrap"><div id="map" class="map"></div>' +
      '<button class="map-btn" id="map-locate" aria-label="موقعي">' + M.components.icon('locate', 22) + '</button></div>' +
      '<div class="card" id="nearest-card">' + M.components.state.loading('جارٍ تحديد أقرب موقف...') + '</div>';
  },
  mount: function (root) { M.views.mapController.start(root); },
  unmount: function () { M.views.mapController.stop(); }
};
