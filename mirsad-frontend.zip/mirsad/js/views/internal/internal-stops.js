M.views.internalStops = {
  render: function () {
    return '<div id="stops-list">' + M.data.stops.map(function (s) {
      const fav = M.services.favorites.has(s.id);
      return M.components.cards.row({ icon: 'pin', to: '/internal/stop/' + s.id, title: s.name,
        text: 'عدد المنتظرين: ' + M.services.waiting.countAt(s.id),
        badge: fav ? '<span class="chip chip--star">' + M.components.icon('star', 14) + '</span>' : '' });
    }).join('') + '</div>';
  }
};
