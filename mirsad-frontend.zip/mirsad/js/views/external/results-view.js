M.views.externalResults = {
  render: function () {
    const q = M.core.store.get('search', null), C = M.components;
    if (!q) return C.header({ title: 'الرحلات', back: '/external' }) + C.state.empty('ابدأ بالبحث عن رحلة', 'search');
    const T = M.services.trips, g = M.data.governorate;
    const trips = T.search(q.from, q.to, q.date, q.time);
    const info = T.info(q.from, q.to);
    return C.header({ title: g(q.from).name + ' ← ' + g(q.to).name, back: '/external' }) +
      C.demoBanner('backend', 'الرحلات والأسعار تجريبية.') +
      '<div class="page"><p class="muted">' + M.utils.format.date(q.date + 'T12:00:00') + ' · المسافة التقريبية ' + info.km + ' كم</p>' +
      (trips.length ? trips.map(C.tripCard).join('') :
        C.state.empty('لا توجد رحلات متاحة في هذا التاريخ والوقت. جرّب وقتاً أو تاريخاً آخر.', 'bus')) + '</div>';
  }
};
