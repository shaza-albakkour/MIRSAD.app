M.views.externalSearch = {
  options: function (sel) {
    return M.data.governorates.map(function (g) {
      return '<option value="' + g.id + '"' + (g.id === sel ? ' selected' : '') + '>' + g.name + '</option>';
    }).join('');
  },
  render: function () {
    const last = M.core.store.get('search', { from: 'idlib', to: 'damascus', time: '' }), C = M.components;
    const times = '<option value="">أي وقت</option>' + M.services.trips.times.map(function (t) {
      return '<option value="' + t + '"' + (t === last.time ? ' selected' : '') + '>بعد ' + t + '</option>';
    }).join('');
    return C.header({ title: 'النقل الخارجي' }) +
      C.demoBanner('backend', 'جدول الرحلات والأسعار والمقاعد تجريبية حتى ربط نظام الإدارة.') +
      '<div class="page"><div class="card search">' +
      '<label class="field"><span class="field__label">من</span><select class="select" id="from">' + this.options(last.from) + '</select></label>' +
      '<button class="swap" id="swap" aria-label="تبديل">' + C.icon('swap', 20) + '</button>' +
      '<label class="field"><span class="field__label">إلى</span><select class="select" id="to">' + this.options(last.to) + '</select></label>' +
      '<label class="field"><span class="field__label">تاريخ السفر</span><input class="select" type="date" id="date" min="' +
      M.utils.format.isoDate() + '" value="' + (last.date && last.date >= M.services.trips.defaultDate() ? last.date : M.services.trips.defaultDate()) + '"></label>' +
      '<label class="field"><span class="field__label">وقت الانطلاق</span><select class="select" id="time">' + times + '</select></label>' +
      '<p class="field__error" id="search-error"></p>' +
      '<button class="btn btn--block" id="search-btn">' + C.icon('search', 20) + ' عرض الرحلات المتاحة</button></div></div>';
  }
};
