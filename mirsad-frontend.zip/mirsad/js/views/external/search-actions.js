M.views.externalSearch.mount = function (root) {
  const v = function (id) { return M.core.dom.val(id, root); };
  root.querySelector('#swap').onclick = function () {
    const f = root.querySelector('#from'), t = root.querySelector('#to'), x = f.value;
    f.value = t.value; t.value = x;
  };
  root.querySelector('#search-btn').onclick = function () {
    const err = root.querySelector('#search-error');
    if (v('from') === v('to')) { err.textContent = 'اختر محافظتين مختلفتين'; return; }
    if (!v('date')) { err.textContent = 'اختر تاريخ السفر'; return; }
    M.core.store.set('search', { from: v('from'), to: v('to'), date: v('date'), time: v('time') });
    M.core.router.go('/external/results');
  };
};
