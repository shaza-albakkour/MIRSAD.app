M.views.checkout.mount = function (root, p) {
  const btn = root.querySelector('#pay-btn');
  if (!btn) return;
  btn.onclick = async function () {
    const seats = btn.dataset.seats.split(',').map(Number);
    const ok = await M.components.modal.confirm({
      title: 'تأكيد الحجز والدفع', text: 'سيتم دفع ثمن ' + seats.length + ' مقعد وإصدار التذكرة.', ok: 'ادفع الآن'
    });
    if (!ok) return;
    M.components.busy(btn, async function () {
      const r = await M.services.booking.confirm(p.tripId, seats);
      if (!r.ok) return M.components.toast.show(r.error, 'error');
      M.components.toast.show('تم تأكيد الحجز وإصدار التذكرة', 'success');
      M.services.notifications.push({ title: 'تأكيد الحجز', body: 'تم إصدار تذكرتك بنجاح', link: '/tickets/' + r.tickets[0].id, kind: 'booking' });
      M.core.router.replace('/tickets/' + r.tickets[0].id);
    });
  };
};
