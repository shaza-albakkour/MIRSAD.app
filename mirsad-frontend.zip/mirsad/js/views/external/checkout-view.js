M.views.checkout = {
  mySeats: function (tripId) {
    const me = M.services.auth.current().id;
    return M.services.seats.holds().filter(function (h) { return h.tripId === tripId && h.userId === me; });
  },
  render: function (p) {
    const t = M.services.trips.get(p.tripId), C = M.components, F = M.utils.format, me = M.services.auth.current();
    const holds = t ? this.mySeats(t.id) : [];
    if (!t || !holds.length) return C.header({ title: 'تأكيد الحجز', back: '/external' }) +
      C.state.error('انتهت مهلة حجز المقاعد أو لم تختر مقعداً. ارجع واختر من جديد.');
    const seats = holds.map(function (h) { return h.seat; }).sort(function (a, b) { return a - b; });
    const early = new Date(t.departure - M.config.app.boarding.arriveEarlyMinutes * 60000);
    return C.header({ title: 'تأكيد الحجز', back: '/external/seats/' + t.id }) +
      C.demoBanner('payment', 'الدفع عبر شام كاش غير مربوط بعد. العملية ستكون تجريبية ولن يُخصم أي مبلغ.') +
      '<div class="page"><div class="card">' +
      this.kv('الرحلة', M.data.governorate(t.from).name + ' ← ' + M.data.governorate(t.to).name) +
      this.kv('الانطلاق', F.date(t.departure) + ' · ' + F.time(t.departure)) +
      this.kv('موعد الحضور للموقف', F.time(early)) + this.kv('المسافر', M.core.dom.esc(me.name)) +
      this.kv('المقاعد', seats.join('، ')) + this.kv('الإجمالي', '<b>' + F.money(t.price * seats.length) + '</b>') + '</div>' +
      '<div class="card pay"><label><input type="radio" name="pay" checked> ' + C.icon('wallet', 20) + ' شام كاش (Sham Cash)</label></div>' +
      '<p class="muted small">تُحجز المقاعد لك حتى ' + F.time(holds[0].exp) + '</p>' +
      '<button class="btn btn--block" id="pay-btn" data-seats="' + seats.join(',') + '">تأكيد وإتمام الدفع</button></div>';
  },
  kv: function (k, v) { return '<div class="kv"><span>' + k + '</span><span>' + v + '</span></div>'; }
};
