M.views.seats.mount = function (root, p) {
  const self = this, F = M.utils.format, trip = M.services.trips.get(p.tripId);
  if (!trip) return;
  const refresh = function () {
    root.querySelector('#seat-grid').innerHTML = self.grid(trip.id);
    root.querySelector('#seat-total').textContent = F.money(trip.price * self.selected.length);
    root.querySelector('#seat-next').disabled = !self.selected.length;
    root.querySelector('#seat-note').textContent = self.selected.length
      ? self.selected.map(function (n) { return 'مقعد ' + n + ' (' + M.services.seats.position(n) + ')'; }).join(' · ')
      : 'اضغط على مقعد لاختياره (حتى 4 مقاعد)';
  };
  root.querySelector('#seat-grid').addEventListener('click', function (e) {
    const b = e.target.closest('[data-seat]');
    if (!b) return;
    const n = Number(b.dataset.seat), i = self.selected.indexOf(n);
    if (i >= 0) self.selected.splice(i, 1);
    else if (self.selected.length >= 4) return M.components.toast.show('الحد الأقصى 4 مقاعد للحجز الواحد', 'error');
    else self.selected.push(n);
    refresh();
  });
  root.querySelector('#seat-next').onclick = function () {
    const r = M.services.seats.hold(trip.id, self.selected);
    if (!r.ok) { self.selected = []; refresh(); return M.components.toast.show(r.error, 'error'); }
    M.core.router.go('/external/checkout/' + trip.id);
  };
  this.timer = setInterval(refresh, 5000);
};
M.views.seats.unmount = function () { clearInterval(this.timer); };
