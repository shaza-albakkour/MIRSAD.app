M.views.seats = {
  selected: [],
  render: function (p) {
    const t = M.services.trips.get(p.tripId), C = M.components, F = M.utils.format;
    if (!t) return C.header({ title: 'رحلة غير صالحة', back: '/external' }) + C.state.error('تعذر العثور على الرحلة');
    this.selected = [];
    const g = M.data.governorate;
    return C.header({ title: 'اختيار المقعد', back: '/external/results' }) +
      '<div class="page"><div class="card"><strong>' + g(t.from).name + ' ← ' + g(t.to).name + '</strong>' +
      '<p class="muted">' + F.date(t.departure) + ' · ' + F.time(t.departure) + ' · ' + t.busType + '</p></div>' +
      '<div class="legend"><span class="seat seat--free"></span>متاح<span class="seat seat--taken"></span>محجوز' +
      '<span class="seat seat--mine"></span>مختار<span class="seat seat--held"></span>قيد الحجز</div>' +
      '<div class="bus-plan"><div class="bus-plan__driver">' + C.icon('wheel', 26) + '</div><div id="seat-grid">' + this.grid(t.id) + '</div></div>' +
      '<p class="muted small" id="seat-note">اضغط على مقعد لاختياره (حتى 4 مقاعد)</p></div>' +
      '<div class="bar"><div><small>الإجمالي</small><b id="seat-total">' + F.money(0) + '</b></div>' +
      '<button class="btn" id="seat-next" disabled>متابعة للحجز</button></div>';
  },
  grid: function (tripId) {
    const self = this;
    return M.services.seats.rows().map(function (row) {
      return '<div class="seat-row">' + row.map(function (n) {
        if (n === null) return '<span class="aisle"></span>';
        let st = M.services.seats.state(tripId, n);
        if (self.selected.indexOf(n) >= 0) st = 'mine';
        return '<button class="seat seat--' + st + '" data-seat="' + n + '"' + (st === 'taken' || st === 'held' ? ' disabled' : '') + '>' + n + '</button>';
      }).join('') + '</div>';
    }).join('');
  }
};
