M.views.ticket = {
  render: function (p) {
    const t = M.services.tickets.get(p.id), C = M.components;
    if (!t) return C.header({ title: 'التذكرة', back: '/tickets' }) + C.state.error('التذكرة غير موجودة');
    const trip = M.services.trips.get(t.tripId), F = M.utils.format, g = M.data.governorate, d = trip.driver;
    const early = new Date(trip.departure - M.config.app.boarding.arriveEarlyMinutes * 60000);
    const row = function (k, v) { return '<div class="kv"><span>' + k + '</span><b>' + v + '</b></div>'; };
    return C.header({ title: 'التذكرة الإلكترونية', back: '/tickets' }) +
      '<div class="page">' + (t.demo ? '<div class="demo-banner">' + C.icon('info', 16) + '<span>تذكرة تجريبية: الدفع لم يتم عبر شام كاش الحقيقي.</span></div>' : '') +
      '<div class="card ticket"><div class="ticket__top"><small>رقم التذكرة</small><b>' + t.number + '</b></div>' +
      '<h2>' + g(trip.from).name + ' ← ' + g(trip.to).name + '</h2>' +
      row('المسافر', M.core.dom.esc(t.passenger)) + row('التاريخ', F.date(trip.departure)) +
      row('الانطلاق', F.time(trip.departure)) + row('الحضور للموقف قبل', F.time(early)) +
      row('المقعد', t.seat + ' (' + M.services.seats.position(t.seat) + ')') + row('موقف الانطلاق', trip.fromStop) +
      '<div class="ticket__qr" id="qr" data-code="' + M.core.dom.esc(t.qr) + '"></div>' +
      '<small class="muted">اعرض الرمز عند الصعود إلى الباص</small></div>' +
      '<div class="card"><h3>معلومات السائق</h3>' + row('الاسم', d.name) + row('الهاتف', '<a href="tel:' + d.phone + '">' + d.phone + '</a>') +
      row('لوحة الباص', trip.plate) + '</div></div>';
  },
  mount: function (root) {
    const el = root.querySelector('#qr');
    if (!el) return;
    if (window.QRCode) new QRCode(el, { text: el.dataset.code, width: 170, height: 170 });
    else el.innerHTML = '<code class="small">' + el.dataset.code + '</code>';
  }
};
