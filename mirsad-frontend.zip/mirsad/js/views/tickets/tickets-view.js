M.views.tickets = {
  tab: 'current',
  render: function () {
    const T = M.services.tickets, all = T.list(), self = this;
    const items = all.filter(function (t) { return (self.tab === 'past') === T.isPast(t); });
    const tabs = [{ key: 'current', label: 'الحالية' }, { key: 'past', label: 'السابقة' }].map(function (x) {
      return '<button class="' + (x.key === self.tab ? 'is-active' : '') + '" data-tab="' + x.key + '">' + x.label + '</button>';
    }).join('');
    return M.components.header({ title: 'تذاكري' }) + '<div class="segmented segmented--btn">' + tabs + '</div><div class="page">' +
      (items.length ? items.map(M.views.ticketCard).join('') :
        M.components.state.empty(self.tab === 'past' ? 'لا توجد رحلات سابقة' : 'لا توجد تذاكر حالية. احجز رحلتك من النقل الخارجي.', 'ticket')) + '</div>';
  },
  mount: function (root) {
    const self = this;
    root.addEventListener('click', function (e) {
      const b = e.target.closest('[data-tab]');
      if (b) { self.tab = b.dataset.tab; M.core.router.render(); }
    });
  }
};
