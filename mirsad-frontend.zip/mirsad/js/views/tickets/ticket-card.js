/* بطاقة تذكرة مختصرة في القوائم */
M.views.ticketCard = function (t) {
  const trip = M.services.trips.get(t.tripId), F = M.utils.format, g = M.data.governorate;
  return '<a class="card ticket-mini" href="#/tickets/' + t.id + '"><div><strong>' +
    g(trip.from).name + ' ← ' + g(trip.to).name + '</strong><small>' + F.date(t.departure) + ' · ' + F.time(t.departure) +
    '</small></div><div class="ticket-mini__seat"><small>مقعد</small><b>' + t.seat + '</b></div></a>';
};
