M.views.complaints = {
  render: function () {
    const C = M.components, list = M.services.complaints.list(), st = M.data.complaintStatuses;
    return C.header({ title: 'الشكاوى والدعم', back: '/profile' }) + '<div class="page">' +
      C.demoBanner('backend', 'الشكاوى محفوظة على جهازك حالياً، وسيصلها فريق الزاجل بعد ربط الخادم.') +
      '<a class="btn btn--block" href="#/complaints/new">' + C.icon('plus', 18) + ' تقديم شكوى جديدة</a>' +
      (list.length ? list.map(function (c) {
        const fresh = c.replies.length > c.seenReplies;
        return C.cards.row({ icon: 'message', to: '/complaints/' + c.ref, title: c.type,
          text: c.ref + ' · ' + st[c.status], badge: fresh ? '<i class="dot dot--inline"></i>' : '' });
      }).join('') : C.state.empty('لم تقدّم أي شكوى بعد', 'message')) + '</div>';
  }
};
