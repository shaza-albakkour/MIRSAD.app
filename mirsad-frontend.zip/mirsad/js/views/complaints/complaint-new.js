M.views.complaintNew = {
  attachment: null,
  render: function () {
    const C = M.components, types = M.data.complaintTypes.map(function (t) { return '<option>' + t + '</option>'; }).join('');
    this.attachment = null;
    return C.header({ title: 'شكوى جديدة', back: '/complaints' }) + '<form class="page" id="cp-form" novalidate>' +
      '<label class="field"><span class="field__label">نوع المشكلة</span><select class="select" id="cp-type"><option value="">اختر...</option>' + types + '</select></label>' +
      '<label class="field"><span class="field__label">التفاصيل</span><textarea class="select" id="cp-details" rows="5" placeholder="اشرح المشكلة بالتفصيل"></textarea></label>' +
      '<label class="btn btn--ghost btn--block">' + C.icon('camera', 18) + ' إرفاق صورة (اختياري)<input type="file" id="cp-file" accept="image/*" hidden></label>' +
      '<small class="muted" id="cp-file-name"></small><p class="field__error" id="cp-error"></p>' +
      '<button class="btn btn--block" type="submit">إرسال الشكوى</button></form>';
  },
  mount: function (root) {
    const self = this;
    root.querySelector('#cp-file').onchange = function (e) {
      const f = e.target.files[0], err = root.querySelector('#cp-error');
      if (!f) return;
      if (f.size > 400 * 1024) { err.textContent = 'الصورة كبيرة، اختر صورة أقل من 400 كيلوبايت'; e.target.value = ''; return; }
      const r = new FileReader();
      r.onload = function () { self.attachment = { name: f.name, data: r.result }; root.querySelector('#cp-file-name').textContent = f.name; };
      r.readAsDataURL(f);
    };
    root.querySelector('#cp-form').onsubmit = async function (e) {
      e.preventDefault();
      const r = M.services.complaints.create({ type: M.core.dom.val('cp-type', root), details: M.core.dom.val('cp-details', root), attachment: self.attachment });
      if (!r.ok) { root.querySelector('#cp-error').textContent = r.error; return; }
      M.components.toast.show('تم إرسال الشكوى. رقمها المرجعي ' + r.ref, 'success');
      M.core.router.replace('/complaints/' + r.ref);
    };
  }
};
