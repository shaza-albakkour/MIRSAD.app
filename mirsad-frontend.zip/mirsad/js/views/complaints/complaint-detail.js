M.views.complaintDetail = {
  render: function (p) {
    const c = M.services.complaints.get(p.ref), C = M.components, st = M.data.complaintStatuses, E = M.core.dom.esc;
    if (!c) return C.header({ title: 'الشكوى', back: '/complaints' }) + C.state.error('الشكوى غير موجودة');
    const steps = Object.keys(st).map(function (k) {
      return '<li class="' + (c.history.some(function (h) { return h.status === k; }) ? 'is-done' : '') + '">' + st[k] + '</li>';
    }).join('');
    return C.header({ title: 'الشكوى ' + c.ref, back: '/complaints' }) + '<div class="page"><div class="card"><strong>' + E(c.type) + '</strong>' +
      '<p>' + E(c.details) + '</p>' + (c.attachment ? '<img class="attach" src="' + c.attachment.data + '" alt="مرفق">' : '') + '</div>' +
      '<div class="card"><h3>حالة الشكوى</h3><ol class="steps">' + steps + '</ol></div>' +
      '<div class="card"><h3>رد الإدارة</h3>' + (c.replies.length ? c.replies.map(function (r) { return '<p>' + E(r.text) + '</p>'; }).join('') :
        '<p class="muted">لم يصل رد بعد.</p>') + '</div></div>';
  },
  mount: function (root, p) { M.services.complaints.markSeen(p.ref); }
};
