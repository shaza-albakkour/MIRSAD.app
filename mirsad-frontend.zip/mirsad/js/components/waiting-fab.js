/* زر «أنا بانتظار الباص» العائم */
M.components.waitingFab = function () {
  const active = M.services.waiting.mine();
  return '<button class="fab' + (active ? ' fab--active' : '') + '" id="waiting-fab">' +
    M.components.icon('hand', 22) + '<span>' + (active ? 'طلب الانتظار فعّال' : 'أنا بانتظار الباص') + '</span></button>';
};
