/* بطاقة رحلة بين المحافظات */
M.components.tripCard = function (t) {
  const F = M.utils.format, free = M.services.seats.available(t.id);
  const hours = Math.floor(t.durationMin / 60) + ' س ' + (t.durationMin % 60) + ' د';
  return '<a class="card trip-card' + (free ? '' : ' is-full') + '" href="#' + (free ? '/external/seats/' + t.id : '/external/results') + '">' +
    '<div class="trip-card__times"><b>' + F.time(t.departure) + '</b><i></i><small>' + hours + '</small><i></i><b>' + F.time(t.arrival) + '</b></div>' +
    '<div class="trip-card__meta"><span>' + t.fromStop + ' ← ' + t.toStop + '</span>' +
    '<span>' + t.busType + '</span></div>' +
    '<div class="trip-card__foot"><strong>' + F.money(t.price) + '</strong>' +
    '<span class="chip' + (free < 6 ? ' chip--warn' : '') + '">' + (free ? free + ' مقعد متاح' : 'مكتملة') + '</span></div></a>';
};
