M.files('js/components', [
  'icon.js', 'state.js', 'toast.js', 'modal.js', 'field.js', 'header.js', 'nav.js',
  'demo-banner.js', 'tabs.js', 'cards.js', 'bus-card.js', 'trip-card.js', 'waiting-fab.js', 'busy.js'
]);
