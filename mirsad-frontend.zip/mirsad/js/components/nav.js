/* القائمة السفلية الخمسة */
M.components.nav = {
  items: [
    { key: 'home', label: 'الرئيسية', icon: 'home', to: '/home' },
    { key: 'internal', label: 'النقل الداخلي', icon: 'bus', to: '/internal/map' },
    { key: 'external', label: 'النقل الخارجي', icon: 'route', to: '/external' },
    { key: 'tickets', label: 'تذاكري', icon: 'ticket', to: '/tickets' },
    { key: 'profile', label: 'حسابي', icon: 'user', to: '/profile' }
  ],
  sync: function (active, visible) {
    const nav = document.getElementById('nav');
    nav.hidden = !visible;
    document.getElementById('app').classList.toggle('has-nav', !!visible);
    if (!visible) return;
    const badge = M.services.complaints.unreadReplies();
    nav.innerHTML = this.items.map(function (i) {
      return '<a href="#' + i.to + '" class="nav__item' + (i.key === active ? ' is-active' : '') + '">' +
        M.components.icon(i.icon, 22) + '<span>' + i.label + '</span>' +
        (i.key === 'profile' && badge ? '<i class="dot"></i>' : '') + '</a>';
    }).join('');
  }
};
