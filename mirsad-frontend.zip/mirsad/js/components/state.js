/* حالات التحميل والخطأ والفراغ */
M.components.state = {
  loading: function (text) {
    return '<div class="state"><div class="spinner"></div><p>' + (text || 'جارٍ التحميل...') + '</p></div>';
  },
  error: function (text, retryId) {
    return '<div class="state state--error">' + M.components.icon('alert', 34) + '<p>' + text + '</p>' +
      (retryId ? '<button class="btn btn--ghost" id="' + retryId + '">إعادة المحاولة</button>' : '') + '</div>';
  },
  empty: function (text, icon) {
    return '<div class="state">' + M.components.icon(icon || 'empty', 34) + '<p>' + text + '</p></div>';
  }
};
