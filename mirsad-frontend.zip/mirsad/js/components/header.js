/* ترويسة الصفحة الداخلية (عودة + عنوان + إجراء اختياري) */
M.components.header = function (o) {
  return '<header class="topbar">' +
    (o.back ? '<a class="icon-btn" href="#' + o.back + '" aria-label="عودة">' + M.components.icon('back', 22) + '</a>' : '') +
    '<h1>' + o.title + '</h1>' + (o.action || '') + '</header>';
};
