/* تبويبات مقسّمة (Segmented) تعتمد على الروابط */
M.components.tabs = function (items, active) {
  return '<div class="segmented">' + items.map(function (t) {
    return '<a href="#' + t.to + '" class="' + (t.key === active ? 'is-active' : '') + '">' + t.label + '</a>';
  }).join('') + '</div>';
};
