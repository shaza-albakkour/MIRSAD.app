/* نافذة تأكيد ونافذة سفلية (Bottom Sheet) */
M.components.modal = {
  close: function () { document.getElementById('overlay').querySelectorAll('.modal').forEach(function (m) { m.remove(); }); },
  sheet: function (html, onMount) {
    this.close();
    const el = document.createElement('div');
    el.className = 'modal';
    el.innerHTML = '<div class="modal__box">' + html + '</div>';
    el.addEventListener('click', function (e) { if (e.target === el) el.remove(); });
    document.getElementById('overlay').appendChild(el);
    if (onMount) onMount(el);
    return el;
  },
  confirm: function (opts) {
    const self = this;
    return new Promise(function (resolve) {
      const el = self.sheet('<h3>' + opts.title + '</h3><p class="muted">' + (opts.text || '') + '</p>' +
        '<div class="row"><button class="btn btn--ghost" data-no>إلغاء</button>' +
        '<button class="btn ' + (opts.danger ? 'btn--danger' : '') + '" data-yes>' + (opts.ok || 'تأكيد') + '</button></div>');
      el.querySelector('[data-yes]').onclick = function () { el.remove(); resolve(true); };
      el.querySelector('[data-no]').onclick = function () { el.remove(); resolve(false); };
    });
  }
};
