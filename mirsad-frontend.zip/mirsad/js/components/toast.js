/* رسائل منبثقة قصيرة؛ الضغط عليها ينقل إلى الرابط إن وُجد */
M.components.toast = {
  show: function (text, kind, link) {
    const el = document.createElement('div');
    el.className = 'toast toast--' + (kind || 'info');
    el.textContent = text;
    el.onclick = function () { if (link) M.core.router.go(link); el.remove(); };
    document.getElementById('overlay').appendChild(el);
    setTimeout(function () { el.remove(); }, 5000);
  }
};
