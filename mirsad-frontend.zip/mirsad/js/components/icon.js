/* أيقونة SVG من سجل الأيقونات */
M.components.icon = function (name, size) {
  const s = size || 22;
  return '<svg class="icon" width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" ' +
    'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    (M.icons[name] || '') + '</svg>';
};
