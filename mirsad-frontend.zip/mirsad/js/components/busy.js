/* يعطّل الزر أثناء تنفيذ عملية غير متزامنة (يمنع الضغط المزدوج) */
M.components.busy = async function (btn, task) {
  if (btn.disabled) return;
  const label = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner spinner--sm"></span>';
  try { return await task(); }
  finally { btn.disabled = false; btn.innerHTML = btn.dataset.label || label; delete btn.dataset.label; }
};
