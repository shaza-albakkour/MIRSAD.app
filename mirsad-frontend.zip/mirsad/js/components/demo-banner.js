/* شريط يوضّح أن البيانات تجريبية (لا نعرضها كأنها حقيقية) */
M.components.demoBanner = function (provider, text) {
  if (!M.config.isDemo(provider)) return '';
  return '<div class="demo-banner">' + M.components.icon('info', 16) + '<span>' + text + '</span></div>';
};
