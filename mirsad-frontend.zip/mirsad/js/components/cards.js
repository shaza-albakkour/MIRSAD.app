/* بطاقات عامة: قسم رئيسي، صف قائمة */
M.components.cards = {
  hero: function (o) {
    return '<a class="hero-card hero-card--' + o.tone + '" href="#' + o.to + '">' +
      '<span class="hero-card__icon">' + M.components.icon(o.icon, 34) + '</span>' +
      '<span><strong>' + o.title + '</strong><small>' + o.text + '</small></span>' +
      M.components.icon('chevron', 22) + '</a>';
  },
  row: function (o) {
    return '<a class="list-row" href="#' + o.to + '"' + (o.id ? ' data-id="' + o.id + '"' : '') + '>' +
      '<span class="list-row__icon">' + M.components.icon(o.icon, 20) + '</span>' +
      '<span class="list-row__text"><strong>' + o.title + '</strong>' +
      (o.text ? '<small>' + o.text + '</small>' : '') + '</span>' + (o.badge || '') +
      M.components.icon('chevron', 18) + '</a>';
  }
};
