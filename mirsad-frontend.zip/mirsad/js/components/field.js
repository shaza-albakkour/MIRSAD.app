/* حقل إدخال موحّد مع رسالة خطأ */
M.components.field = function (o) {
  const esc = M.core.dom.esc;
  return '<label class="field" for="' + o.id + '"><span class="field__label">' + o.label + '</span>' +
    '<span class="field__box">' + (o.icon ? M.components.icon(o.icon, 18) : '') +
    '<input id="' + o.id + '" type="' + (o.type || 'text') + '" placeholder="' + esc(o.placeholder || '') + '"' +
    ' autocomplete="' + (o.auto || 'off') + '" inputmode="' + (o.mode || 'text') + '"' +
    ' value="' + esc(o.value || '') + '"' + (o.max ? ' maxlength="' + o.max + '"' : '') + '></span>' +
    '<small class="field__error" data-error-for="' + o.id + '"></small></label>';
};
M.components.field.showError = function (root, id, msg) {
  const el = root.querySelector('[data-error-for="' + id + '"]');
  if (el) el.textContent = msg || '';
};
M.components.field.clearErrors = function (root) {
  root.querySelectorAll('.field__error').forEach(function (e) { e.textContent = ''; });
};
