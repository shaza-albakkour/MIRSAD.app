/* بطاقة وصول باص إلى موقف */
M.components.busCard = function (a) {
  const F = M.utils.format, geo = M.utils.geo;
  return '<div class="card bus-card" style="--c:' + a.line.color + '">' +
    '<div class="bus-card__eta"><b>' + F.minutes(a.minutes) + '</b><small>متبقٍ</small></div>' +
    '<div class="bus-card__info"><strong>' + a.bus.code + '</strong><span>' + a.line.name + '</span>' +
    '<small>' + M.components.icon('navigation', 14) + ' يتجه ' + geo.compass(a.bus.bearing) +
    ' نحو ' + M.data.stop(a.bus.nextStopId).name + '</small>' +
    '<small>يبعد ' + F.distance(a.distance) + ' عن الموقف</small></div></div>';
};
