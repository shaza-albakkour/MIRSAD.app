/* الشكاوى: تُحفظ محلياً الآن وتُربط بحساب المستخدم، وجاهزة للربط بالخادم */
M.services.complaints = {
  list: function () { return M.core.userStore.get('complaints', []); },
  get: function (ref) { return this.list().find(function (c) { return c.ref === ref; }); },
  create: function (data) {
    if (!data.type) return { ok: false, error: 'اختر نوع المشكلة' };
    if (data.details.length < 10) return { ok: false, error: 'اكتب تفاصيل لا تقل عن 10 أحرف' };
    const c = {
      ref: M.utils.ids.ref('CP'), type: data.type, details: data.details,
      attachment: data.attachment || null, status: 'new', createdAt: Date.now(),
      history: [{ status: 'new', at: Date.now() }], replies: [], seenReplies: 0
    };
    M.core.userStore.set('complaints', [c].concat(this.list()));
    return { ok: true, ref: c.ref };
  },
  unreadReplies: function () {
    return this.list().reduce(function (n, c) { return n + (c.replies.length - c.seenReplies); }, 0);
  },
  markSeen: function (ref) {
    M.core.userStore.set('complaints', this.list().map(function (c) {
      return c.ref === ref ? Object.assign({}, c, { seenReplies: c.replies.length }) : c;
    }));
  }
};
