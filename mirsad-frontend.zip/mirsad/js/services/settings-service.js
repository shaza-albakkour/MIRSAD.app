/* إعدادات المستخدم: الإشعارات والمسافة */
M.services.settings = {
  defaults: {
    approach: true, schedule: true, booking: true, complaints: true,
    radiusKm: 1, push: true
  },
  get: function () {
    return Object.assign({}, this.defaults, M.core.userStore.get('settings', {}));
  },
  set: function (patch) {
    M.core.userStore.set('settings', Object.assign(this.get(), patch));
  }
};
