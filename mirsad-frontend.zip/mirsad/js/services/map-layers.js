/* طبقات الخريطة: المواقف، خطوط السير، الباصات، موقع المستخدم */
M.services.mapLayers = {
  stops: function (map, onClick) {
    return M.data.stops.map(function (s) {
      const icon = L.divIcon({ className: '', html: '<div class="stop-marker"></div>', iconSize: [18, 18] });
      const m = L.marker(s.pos, { icon: icon }).addTo(map).bindTooltip(s.name);
      m.on('click', function () { onClick(s); });
      return m;
    });
  },
  lines: function (map) {
    M.data.lines.forEach(function (l) {
      L.polyline(M.services.tracking.pathOf(l).pts, { color: l.color, weight: 5, opacity: 0.75 }).addTo(map);
    });
  },
  busIcon: function (bus) {
    const c = M.data.line(bus.line).color;
    return L.divIcon({
      className: '', iconSize: [34, 34],
      html: '<div class="bus-marker" style="--c:' + c + '"><span style="transform:rotate(' +
        Math.round(bus.bearing) + 'deg)">▲</span></div>'
    });
  },
  buses: function (map, markers) {
    M.services.tracking.buses().forEach(function (bus) {
      if (markers[bus.id]) {
        markers[bus.id].setLatLng(bus.pos).setIcon(M.services.mapLayers.busIcon(bus));
      } else {
        markers[bus.id] = L.marker(bus.pos, { icon: M.services.mapLayers.busIcon(bus), zIndexOffset: 500 })
          .addTo(map).bindTooltip(bus.code);
      }
    });
  },
  user: function (map, pos, ref) {
    if (ref.user) ref.user.setLatLng(pos);
    else ref.user = L.circleMarker(pos, { radius: 9, color: '#fff', weight: 3, fillColor: '#2563EB', fillOpacity: 1 }).addTo(map);
  }
};
