/* إنشاء حساب جديد: تحقق من المدخلات ثم OTP ثم إنشاء المستخدم */
M.services.signup = {
  start: async function (f) {
    if (f.name.length < 2) return { ok: false, field: 'name', error: 'اكتب اسماً من حرفين على الأقل' };
    const v = M.utils.phone.validate(f.phone);
    if (!v.valid) return { ok: false, field: 'phone', error: v.error };
    if (f.password.length < 8) return { ok: false, field: 'password', error: 'كلمة المرور 8 أحرف على الأقل' };
    if (f.password !== f.confirm) return { ok: false, field: 'confirm', error: 'كلمتا المرور غير متطابقتين' };
    if (M.services.auth.users().some(function (u) { return u.phone === v.normalized; })) {
      return { ok: false, field: 'phone', error: 'هذا الرقم مسجّل مسبقاً، سجّل الدخول' };
    }
    const salt = M.utils.crypto.random(8);
    M.core.store.set('pending-signup', {
      name: f.name, phone: v.normalized, operator: v.operator,
      salt: salt, hash: await M.utils.crypto.sha256(salt + f.password)
    });
    return Object.assign({ phone: v.normalized }, await M.services.otp.send(v.normalized, 'signup'));
  },
  pending: function () { return M.core.store.get('pending-signup', null); },
  finish: async function (code) {
    const p = this.pending();
    if (!p) return { ok: false, error: 'انتهت جلسة التسجيل، ابدأ من جديد' };
    const r = await M.services.otp.verify(p.phone, 'signup', code);
    if (!r.ok) return r;
    const user = Object.assign({ id: M.utils.ids.uid('u'), createdAt: Date.now() }, p);
    M.services.auth.saveUsers(M.services.auth.users().concat(user));
    M.core.store.set('session', user.id);
    M.core.store.remove('pending-signup');
    return { ok: true };
  }
};
