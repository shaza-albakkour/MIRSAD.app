/* حالة المقاعد وقفلها مؤقتاً لمنع الحجز المزدوج */
Object.assign(M.services.seats, {
  holds: function () {
    const now = Date.now();
    return M.core.store.get('seat-holds', []).filter(function (h) { return h.exp > now; });
  },
  booked: function (tripId) {
    const self = this;
    return M.core.store.get('bookings', []).filter(function (b) { return b.tripId === tripId; })
      .map(function (b) { return b.seat; })
      .concat(self.allSeats().filter(function (n) { return self.demoTaken(tripId, n); }));
  },
  allSeats: function () {
    return [].concat.apply([], this.rows()).filter(Boolean);
  },
  state: function (tripId, n) {
    const me = M.services.auth.current().id;
    if (this.booked(tripId).indexOf(n) >= 0) return 'taken';
    const h = this.holds().find(function (x) { return x.tripId === tripId && x.seat === n; });
    return h ? (h.userId === me ? 'mine' : 'held') : 'free';
  },
  available: function (tripId) {
    const self = this;
    return this.allSeats().filter(function (n) { return self.state(tripId, n) === 'free'; }).length;
  },
  hold: function (tripId, seats) {
    const me = M.services.auth.current().id, self = this;
    if (seats.some(function (n) { return ['free', 'mine'].indexOf(self.state(tripId, n)) < 0; })) {
      return { ok: false, error: 'أحد المقاعد لم يعد متاحاً، اختر مقعداً آخر' };
    }
    const exp = Date.now() + M.config.app.booking.seatHoldMinutes * 60000;
    const others = this.holds().filter(function (h) { return !(h.tripId === tripId && h.userId === me); });
    M.core.store.set('seat-holds', others.concat(seats.map(function (n) { return { tripId: tripId, seat: n, userId: me, exp: exp }; })));
    return { ok: true, exp: exp };
  },
  release: function (tripId) {
    const me = M.services.auth.current().id;
    M.core.store.set('seat-holds', this.holds().filter(function (h) { return !(h.tripId === tripId && h.userId === me); }));
  }
});
