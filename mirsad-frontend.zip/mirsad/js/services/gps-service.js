/* تحديد موقع المستخدم (مع وضع محاكاة اختياري للتجربة) */
M.services.gps = {
  simulatedPos: [35.9308, 36.6338],
  isSimulated: function () { return M.core.store.get('gps-sim', false); },
  setSimulated: function (on) { M.core.store.set('gps-sim', !!on); },
  messages: {
    denied: 'تم رفض إذن الموقع. فعّله من إعدادات المتصفح.',
    unavailable: 'تعذر تحديد موقعك حالياً.',
    unsupported: 'جهازك لا يدعم تحديد الموقع.'
  },
  get: function () {
    const self = this;
    return new Promise(function (resolve) {
      if (self.isSimulated()) return resolve({ ok: true, pos: self.simulatedPos, simulated: true });
      if (!navigator.geolocation) return resolve({ ok: false, error: self.messages.unsupported });
      navigator.geolocation.getCurrentPosition(function (p) {
        resolve({ ok: true, pos: [p.coords.latitude, p.coords.longitude], accuracy: p.coords.accuracy });
      }, function (e) {
        resolve({ ok: false, error: e.code === 1 ? self.messages.denied : self.messages.unavailable });
      }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 15000 });
    });
  }
};
