/* استعلامات فوق بيانات التتبع: الوصول للموقف، الأقرب، الفاصل الزمني */
M.services.trackingQuery = {
  arrivals: function (stopId) {
    const T = M.services.tracking, now = Date.now(), list = [];
    T.buses(now).forEach(function (bus) {
      if (M.data.line(bus.line).stops.indexOf(stopId) < 0) return;
      const e = T.eta(bus, stopId, now);
      list.push({ bus: bus, line: M.data.line(bus.line), minutes: e.minutes, distance: e.distance, loop: e.loopMinutes });
    });
    return list.sort(function (a, b) { return a.minutes - b.minutes; });
  },
  headway: function (lineId) {
    const count = M.data.buses.filter(function (b) { return b.line === lineId; }).length;
    const b = M.data.buses.find(function (x) { return x.line === lineId; });
    return count ? M.services.tracking.eta(b, M.data.line(lineId).stops[0], 0).loopMinutes / count : 0;
  },
  nearestStop: function (pos) {
    let best = null;
    M.data.stops.forEach(function (s) {
      const d = M.utils.geo.distance(pos, s.pos);
      if (!best || d < best.distance) best = { stop: s, distance: d };
    });
    return best;
  },
  nearbyBuses: function (pos, limit) {
    const self = this, out = [];
    M.services.tracking.buses().forEach(function (bus) {
      const stops = M.data.line(bus.line).stops.map(M.data.stop);
      let near = null;
      stops.forEach(function (s) {
        const d = M.utils.geo.distance(pos, s.pos);
        if (!near || d < near.distance) near = { stop: s, distance: d };
      });
      const e = M.services.tracking.eta(bus, near.stop.id, Date.now());
      out.push({ bus: bus, stop: near.stop, stopDistance: near.distance, minutes: e.minutes,
        distance: M.utils.geo.distance(pos, bus.pos) });
    });
    return out.sort(function (a, b) { return a.distance - b.distance; }).slice(0, limit || 5);
  }
};
