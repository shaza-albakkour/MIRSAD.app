/* الجلسة وتسجيل الدخول/الخروج (تجريبي محلي إلى حين ربط الخادم) */
M.services.auth = {
  users: function () { return M.core.store.get('users', []); },
  saveUsers: function (list) { M.core.store.set('users', list); },
  current: function () {
    const id = M.core.store.get('session', null);
    return id ? this.users().find(function (u) { return u.id === id; }) || null : null;
  },
  isLoggedIn: function () { return !!this.current(); },
  entryRoute: function () { return this.users().length ? '/login' : '/register'; },
  login: async function (phone, password) {
    const v = M.utils.phone.validate(phone);
    if (!v.valid) return { ok: false, error: v.error };
    const user = this.users().find(function (u) { return u.phone === v.normalized; });
    if (!user) return { ok: false, error: 'لا يوجد حساب بهذا الرقم' };
    const hash = await M.utils.crypto.sha256(user.salt + password);
    if (hash !== user.hash) return { ok: false, error: 'كلمة المرور غير صحيحة' };
    M.core.store.set('session', user.id);
    return { ok: true };
  },
  logout: function () {
    M.core.store.remove('session');
    M.core.events.emit('logout');
  },
  updateProfile: function (patch) {
    const me = this.current();
    this.saveUsers(this.users().map(function (u) { return u.id === me.id ? Object.assign({}, u, patch) : u; }));
  },
  changePassword: async function (oldPass, newPass) {
    const me = this.current();
    if (await M.utils.crypto.sha256(me.salt + oldPass) !== me.hash) {
      return { ok: false, error: 'كلمة المرور الحالية غير صحيحة' };
    }
    this.updateProfile({ hash: await M.utils.crypto.sha256(me.salt + newPass) });
    return { ok: true };
  }
};
