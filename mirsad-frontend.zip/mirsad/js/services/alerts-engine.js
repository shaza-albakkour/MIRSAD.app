/* محرك التنبيهات: يعمل أثناء فتح التطبيق (الخلفية تتطلب Push من الخادم) */
M.services.alerts = (function () {
  let timer = null;
  const sent = {};
  const U = M.utils.format;
  function once(key, minutes) {
    if (sent[key] && Date.now() - sent[key] < minutes * 60000) return false;
    sent[key] = Date.now();
    return true;
  }
  function approach() {
    const s = M.services.settings.get(), req = M.services.waiting.mine();
    if (!s.approach || !req) return;
    const first = M.services.trackingQuery.arrivals(req.stopId)[0];
    if (!first || first.distance > s.radiusKm * 1000) return;
    if (!once('ap:' + req.stopId + first.bus.id, M.config.app.alerts.minGapMinutes)) return;
    M.services.notifications.push({
      title: 'باص الزاجل يقترب', link: '/internal/map', kind: 'approach',
      body: 'باص الزاجل يقترب من موقفك، متوقع وصوله خلال ' + Math.max(1, Math.round(first.minutes)) + ' دقائق'
    });
  }
  function tick() {
    if (!M.services.auth.isLoggedIn()) return;
    approach();
    M.services.alertSchedules.run(once);
  }
  return {
    start: function () {
      if (timer) return;
      timer = setInterval(tick, M.config.app.alerts.checkEverySeconds * 1000);
    },
    stop: function () { clearInterval(timer); timer = null; }
  };
})();
