/* التذاكر الإلكترونية ورمز QR (التحقق النهائي من التوقيع يجب أن يتم في الخادم) */
M.services.tickets = {
  list: function () {
    const me = M.services.auth.current().id;
    return M.core.store.get('tickets', []).filter(function (t) { return t.userId === me; })
      .sort(function (a, b) { return b.departure - a.departure; });
  },
  get: function (id) { return this.list().find(function (t) { return t.id === id; }); },
  secret: function () {
    let s = M.core.store.get('qr-secret', null);
    if (!s) { s = M.utils.crypto.random(16); M.core.store.set('qr-secret', s); }
    return s;
  },
  issue: async function (data) {
    const num = M.utils.ids.ref('TK'), sig = await M.utils.crypto.sha256(this.secret() + num + data.tripId + data.seat);
    const t = Object.assign({
      id: M.utils.ids.uid('t'), number: num, status: 'valid', createdAt: Date.now(),
      qr: ['MIRSAD', num, data.tripId, data.seat, sig.slice(0, 16)].join('|')
    }, data);
    M.core.store.set('tickets', M.core.store.get('tickets', []).concat(t));
    return t;
  },
  isPast: function (t) { return t.departure < Date.now(); }
};
