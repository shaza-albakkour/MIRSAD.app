/* المواقف المفضلة */
M.services.favorites = {
  list: function () { return M.core.userStore.get('favorites', []); },
  has: function (id) { return this.list().indexOf(id) >= 0; },
  toggle: function (id) {
    const l = this.list(), i = l.indexOf(id);
    if (i >= 0) l.splice(i, 1); else l.push(id);
    M.core.userStore.set('favorites', l);
    return i < 0;
  }
};
