/* مصدر مواقع الباصات. الوضع التجريبي يحاكي الحركة على خط السير (ليس GPS حقيقياً). */
M.services.tracking = (function () {
  const geo = M.utils.geo, cache = {};
  function pathOf(line) {
    if (cache[line.id]) return cache[line.id];
    const pts = line.stops.map(function (id) { return M.data.stop(id).pos; });
    pts.push(pts[0]);
    const cum = [0], stopS = {};
    for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + geo.distance(pts[i - 1], pts[i]));
    line.stops.forEach(function (id, i) { stopS[id] = cum[i]; });
    return (cache[line.id] = { pts: pts, cum: cum, total: cum[cum.length - 1], stopS: stopS });
  }
  function progress(bus, now) {
    const p = pathOf(M.data.line(bus.line)), v = bus.speedKmh / 3.6;
    return (bus.offset * p.total + v * now / 1000) % p.total;
  }
  function snapshot(bus, now) {
    const p = pathOf(M.data.line(bus.line)), s = progress(bus, now);
    let i = 0;
    while (i < p.cum.length - 2 && p.cum[i + 1] <= s) i++;
    const a = p.pts[i], b = p.pts[i + 1], f = (s - p.cum[i]) / (p.cum[i + 1] - p.cum[i]);
    return Object.assign({}, bus, {
      pos: [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f],
      bearing: geo.bearing(a, b), s: s, nextStopId: M.data.line(bus.line).stops[(i + 1) % (p.pts.length - 1)]
    });
  }
  function eta(bus, stopId, now) {
    const p = pathOf(M.data.line(bus.line)), v = bus.speedKmh / 3.6;
    const delta = (p.stopS[stopId] - progress(bus, now) + p.total) % p.total;
    return { distance: delta, minutes: delta / v / 60, loopMinutes: p.total / v / 60 };
  }
  function buses(now) {
    if (!M.config.isDemo('tracking')) return [];
    return M.data.buses.map(function (b) { return snapshot(b, now || Date.now()); });
  }
  return { buses: buses, eta: eta, pathOf: pathOf };
})();
