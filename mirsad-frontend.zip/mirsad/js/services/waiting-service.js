/* طلبات «أنا بانتظار الباص». التخزين المحلي بديل مؤقت لخادم تشغيل الرحلات. */
M.services.waiting = {
  cooldownSeconds: 60,
  all: function () {
    const now = Date.now();
    return M.core.store.get('waiting', []).filter(function (r) { return r.status === 'active' && r.expiresAt > now; });
  },
  mine: function () {
    const me = M.services.auth.current();
    return this.all().find(function (r) { return r.userId === me.id; }) || null;
  },
  countAt: function (stopId) {
    return this.all().filter(function (r) { return r.stopId === stopId; }).length;
  },
  request: async function (stopId) {
    const cfg = M.config.app.waiting, me = M.services.auth.current(), S = M.core.store;
    if (this.mine()) return { ok: false, error: 'لديك طلب انتظار فعّال بالفعل' };
    const last = S.get('waiting-last:' + me.id, 0);
    if (Date.now() - last < this.cooldownSeconds * 1000) return { ok: false, error: 'انتظر قليلاً قبل إرسال طلب جديد' };
    const loc = await M.services.gps.get();
    if (!loc.ok) return { ok: false, error: loc.error };
    const d = M.utils.geo.distance(loc.pos, M.data.stop(stopId).pos);
    if (d > cfg.radiusMeters) return { ok: false, error: 'يجب أن تكون بالقرب من الموقف (أقل من ' + cfg.radiusMeters + ' م). أنت على بعد ' + M.utils.format.distance(d) };
    const req = { id: M.utils.ids.uid('w'), userId: me.id, stopId: stopId, status: 'active',
      createdAt: Date.now(), expiresAt: Date.now() + cfg.ttlMinutes * 60000 };
    S.set('waiting', M.core.store.get('waiting', []).concat(req));
    return { ok: true, request: req };
  },
  cancel: function () {
    const me = M.services.auth.current(), mine = this.mine();
    if (!mine) return;
    M.core.store.set('waiting', M.core.store.get('waiting', []).map(function (r) {
      return r.id === mine.id ? Object.assign({}, r, { status: 'cancelled' }) : r;
    }));
    M.core.store.set('waiting-last:' + me.id, Date.now());
  }
};
