M.files('js/services', [
  'user-store.js', 'auth-service.js', 'otp-service.js', 'signup-service.js', 'password-service.js',
  'gps-service.js', 'tracking-service.js', 'tracking-queries.js', 'map-service.js', 'map-layers.js',
  'settings-service.js', 'notification-service.js', 'favorites-service.js', 'waiting-service.js',
  'schedule-service.js', 'alerts-schedules.js', 'alerts-engine.js', 'trip-service.js', 'seat-layout.js', 'seat-service.js',
  'payment-service.js', 'ticket-service.js', 'booking-service.js', 'complaint-service.js'
]);
