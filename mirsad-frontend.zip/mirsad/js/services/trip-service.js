/* الرحلات بين المحافظات. الجدول مولّد تجريبياً إلى حين ربط الخادم. */
M.services.trips = {
  times: ['06:00', '08:00', '11:00', '14:00', '17:00'],
  makeId: function (from, to, date, time) { return [from, to, date, time.replace(':', '')].join('_'); },
  info: function (from, to) {
    const a = M.data.governorate(from), b = M.data.governorate(to);
    const km = Math.max(10, Math.round(M.utils.geo.distance(a.pos, b.pos) / 1000 * 1.25));
    return { km: km, minutes: Math.round(km / 55 * 60), price: Math.round(km * M.config.app.pricePerKm / 100) * 100 };
  },
  build: function (from, to, date, time) {
    const i = this.info(from, to), dep = new Date(date + 'T' + time + ':00');
    const n = (from.length + to.length + Number(time.slice(0, 2))) % M.data.drivers.length;
    const driver = M.data.drivers[n];
    return {
      id: this.makeId(from, to, date, time), from: from, to: to, date: date, time: time,
      departure: dep.getTime(), arrival: dep.getTime() + i.minutes * 60000,
      durationMin: i.minutes, km: i.km, price: i.price, driver: driver, plate: driver.plate,
      busType: 'حافلة مكيّفة ٤٤ مقعداً', demo: true,
      fromStop: 'كراج ' + M.data.governorate(from).name, toStop: 'كراج ' + M.data.governorate(to).name
    };
  },
  get: function (id) {
    const p = id.split('_');
    return p.length === 4 ? this.build(p[0], p[1], p[2], p[3].slice(0, 2) + ':' + p[3].slice(2)) : null;
  },
  defaultDate: function () {
    const F = M.utils.format, last = this.times[this.times.length - 1];
    const d = new Date(F.isoDate() + 'T' + last + ':00').getTime() > Date.now() ? new Date() : new Date(Date.now() + 864e5);
    return F.isoDate(d);
  },
  search: function (from, to, date, afterTime) {
    const self = this;
    return this.times.filter(function (t) {
      return t >= (afterTime || '00:00') && new Date(date + 'T' + t + ':00').getTime() > Date.now();
    }).map(function (t) { return self.build(from, to, date, t); });
  }
};
