/* الدفع عبر شام كاش. لا نجاح دفع إلا بعد تحقق رسمي؛ الوضع التجريبي معلَّم صراحةً. */
M.services.payment = {
  list: function () { return M.core.store.get('payments', []); },
  gateway: {
    charge: async function () { throw new Error('NOT_CONFIGURED'); },
    verify: async function () { throw new Error('NOT_CONFIGURED'); }
  },
  pay: async function (bookingId, amount) {
    const done = this.list().find(function (p) { return p.bookingId === bookingId && p.status === 'success'; });
    if (done) return { ok: true, payment: done, duplicate: true };
    if (!navigator.onLine) return { ok: false, error: 'لا يوجد اتصال بالإنترنت. لم يُخصم أي مبلغ.' };
    let rec;
    if (M.config.isDemo('payment')) {
      await new Promise(function (r) { setTimeout(r, 1200); });
      rec = { txId: 'DEMO-' + M.utils.crypto.random(5).toUpperCase(), demo: true };
    } else {
      try {
        const tx = await this.gateway.charge(bookingId, amount);
        if (!(await this.gateway.verify(tx.id))) throw new Error('UNVERIFIED');
        rec = { txId: tx.id, demo: false };
      } catch (e) { return { ok: false, error: 'فشلت عملية الدفع ولم يتم تأكيد الحجز.' }; }
    }
    const payment = Object.assign({ bookingId: bookingId, amount: amount, status: 'success', at: Date.now(), method: 'shamcash' }, rec);
    M.core.store.set('payments', this.list().concat(payment));
    return { ok: true, payment: payment };
  }
};
