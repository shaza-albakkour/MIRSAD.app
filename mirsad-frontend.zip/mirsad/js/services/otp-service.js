/* رمز التحقق OTP. الوضع التجريبي يعرض الرمز على الشاشة لعدم وجود مزود SMS. */
M.services.otp = {
  cooldownSeconds: 30, ttlMinutes: 5, maxAttempts: 5,
  provider: { send: async function () { throw new Error('NOT_CONFIGURED'); } },
  send: async function (phone, purpose) {
    const S = M.core.store, prev = S.get('otp', null);
    if (prev && prev.phone === phone && Date.now() - prev.sentAt < this.cooldownSeconds * 1000) {
      return { ok: false, error: 'انتظر قليلاً قبل طلب رمز جديد' };
    }
    const code = String(Math.floor(100000 + Math.random() * 900000));
    if (!M.config.isDemo('otp')) {
      try { await this.provider.send(phone, code); }
      catch (e) { return { ok: false, error: 'تعذر إرسال الرسالة، حاول لاحقاً' }; }
    }
    S.set('otp', {
      phone: phone, purpose: purpose, code: await M.utils.crypto.sha256(code),
      exp: Date.now() + this.ttlMinutes * 60000, attempts: 0, sentAt: Date.now()
    });
    return { ok: true, demoCode: M.config.isDemo('otp') ? code : null };
  },
  verify: async function (phone, purpose, code) {
    const S = M.core.store, rec = S.get('otp', null);
    if (!rec || rec.phone !== phone || rec.purpose !== purpose) return { ok: false, error: 'اطلب رمزاً جديداً' };
    if (Date.now() > rec.exp) return { ok: false, error: 'انتهت صلاحية الرمز' };
    if (rec.attempts >= this.maxAttempts) return { ok: false, error: 'تجاوزت عدد المحاولات، اطلب رمزاً جديداً' };
    rec.attempts += 1; S.set('otp', rec);
    if (await M.utils.crypto.sha256(M.utils.format.digits(code)) !== rec.code) {
      return { ok: false, error: 'الرمز غير صحيح' };
    }
    S.remove('otp');
    return { ok: true };
  }
};
