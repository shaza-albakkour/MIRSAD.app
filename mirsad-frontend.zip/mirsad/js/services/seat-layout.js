/* تخطيط المقاعد (صفوف، موضع المقعد، محاكاة المحجوز التجريبي) */
M.services.seats = {
  rows: function () {
    const cfg = M.config.app.booking, out = [];
    for (let r = 0; r < cfg.rows; r++) {
      out.push([1, 2, null, 3, 4].map(function (c) { return c === null ? null : r * cfg.seatsPerRow + c; }));
    }
    return out;
  },
  position: function (n) {
    const c = (n - 1) % M.config.app.booking.seatsPerRow;
    return c === 0 || c === 3 ? 'بجانب النافذة' : 'بجانب الممر';
  },
  hash: function (s) {
    let h = 7;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 9973;
    return h;
  },
  demoTaken: function (tripId, n) { return this.hash(tripId + n) % 100 < 28; }
};
