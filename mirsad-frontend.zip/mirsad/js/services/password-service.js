/* استعادة كلمة المرور عبر OTP */
M.services.password = {
  start: async function (phone) {
    const v = M.utils.phone.validate(phone);
    if (!v.valid) return { ok: false, error: v.error };
    const exists = M.services.auth.users().some(function (u) { return u.phone === v.normalized; });
    if (!exists) return { ok: false, error: 'لا يوجد حساب بهذا الرقم' };
    return Object.assign({ phone: v.normalized }, await M.services.otp.send(v.normalized, 'reset'));
  },
  finish: async function (phone, code, newPass) {
    if (newPass.length < 8) return { ok: false, error: 'كلمة المرور 8 أحرف على الأقل' };
    const r = await M.services.otp.verify(phone, 'reset', code);
    if (!r.ok) return r;
    const users = M.services.auth.users(), user = users.find(function (u) { return u.phone === phone; });
    user.hash = await M.utils.crypto.sha256(user.salt + newPass);
    M.services.auth.saveUsers(users);
    return { ok: true };
  }
};
