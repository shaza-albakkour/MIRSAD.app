/* سجل الإشعارات + إشعار المتصفح (Push الحقيقي يتطلب خادماً) */
M.services.notifications = {
  list: function () { return M.core.userStore.get('feed', []); },
  unread: function () { return this.list().filter(function (n) { return !n.read; }).length; },
  markAllRead: function () {
    M.core.userStore.set('feed', this.list().map(function (n) { return Object.assign({}, n, { read: true }); }));
    M.core.events.emit('notify');
  },
  push: function (n) {
    const item = Object.assign({ id: M.utils.ids.uid('n'), at: Date.now(), read: false, link: '/home' }, n);
    M.core.userStore.set('feed', [item].concat(this.list()).slice(0, 50));
    M.core.events.emit('notify', item);
    M.components.toast.show(item.body, 'info', item.link);
    if (M.services.settings.get().push && window.Notification && Notification.permission === 'granted') {
      new Notification(item.title, { body: item.body, icon: 'assets/images/logo-mark.svg' });
    }
  },
  requestPermission: async function () {
    if (!window.Notification) return 'unsupported';
    return Notification.requestPermission();
  }
};
