/* إنشاء خريطة Leaflet (OpenStreetMap) مع رسالة بديلة عند غياب الاتصال */
M.services.map = {
  available: function () { return !!window.L; },
  create: function (el, center, zoom) {
    if (!this.available()) {
      el.innerHTML = M.components.state.error('تعذر تحميل مكتبة الخرائط. تحقق من اتصال الإنترنت.');
      return null;
    }
    const cfg = M.config.app;
    const map = L.map(el, { zoomControl: false, attributionControl: true })
      .setView(center || cfg.mapCenter, zoom || cfg.mapZoom);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19, attribution: '© OpenStreetMap'
    }).addTo(map);
    setTimeout(function () { map.invalidateSize(); }, 200);
    return map;
  }
};
