/* تخزين خاص بالمستخدم الحالي (مفتاح = معرّف المستخدم + الاسم) */
M.core.userStore = {
  key: function (name) {
    const u = M.services.auth.current();
    return (u ? u.id : 'guest') + ':' + name;
  },
  get: function (name, fallback) { return M.core.store.get(this.key(name), fallback); },
  set: function (name, value) { return M.core.store.set(this.key(name), value); }
};
