/* جداول التنبيهات المعتادة */
M.services.schedules = {
  dayNames: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
  list: function () { return M.core.userStore.get('schedules', []); },
  get: function (id) { return this.list().find(function (s) { return s.id === id; }); },
  save: function (s) {
    if (!/^\d{2}:\d{2}$/.test(s.time)) return { ok: false, error: 'اختر وقتاً صحيحاً' };
    if (!s.days.length) return { ok: false, error: 'اختر يوماً واحداً على الأقل' };
    const list = this.list();
    if (!s.id) { s.id = M.utils.ids.uid('sc'); s.enabled = true; list.push(s); }
    else list.splice(list.findIndex(function (x) { return x.id === s.id; }), 1, s);
    M.core.userStore.set('schedules', list);
    return { ok: true };
  },
  remove: function (id) {
    M.core.userStore.set('schedules', this.list().filter(function (s) { return s.id !== id; }));
  },
  toggle: function (id) {
    M.core.userStore.set('schedules', this.list().map(function (s) {
      return s.id === id ? Object.assign({}, s, { enabled: !s.enabled }) : s;
    }));
  },
  summary: function (s) {
    const names = s.days.length === 7 ? 'يومياً' : s.days.map(function (d) { return M.services.schedules.dayNames[d]; }).join('، ');
    return names + ' — ' + s.time;
  }
};
