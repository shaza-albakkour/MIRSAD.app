/* الحجز: قفل المقاعد ثم الدفع ثم إصدار التذاكر، مع منع التكرار */
M.services.booking = {
  existing: function (tripId, seats) {
    return M.services.tickets.list().filter(function (t) {
      return t.tripId === tripId && seats.indexOf(t.seat) >= 0;
    });
  },
  confirm: async function (tripId, seats) {
    const trip = M.services.trips.get(tripId), me = M.services.auth.current();
    if (!trip || !seats.length) return { ok: false, error: 'بيانات الحجز غير صالحة' };
    if (this.existing(tripId, seats).length) return { ok: false, error: 'لديك تذكرة لهذا المقعد بالفعل' };
    const held = M.services.seats.hold(tripId, seats);
    if (!held.ok) return held;
    const bookingId = [me.id, tripId, seats.slice().sort().join('-')].join(':');
    const pay = await M.services.payment.pay(bookingId, trip.price * seats.length);
    if (!pay.ok) return pay;
    if (this.existing(tripId, seats).length) return { ok: false, error: 'تم تأكيد هذا الحجز سابقاً' };
    const tickets = [];
    for (const seat of seats) {
      tickets.push(await M.services.tickets.issue({
        tripId: tripId, seat: seat, userId: me.id, passenger: me.name, phone: me.phone,
        departure: trip.departure, paymentTx: pay.payment.txId, demo: pay.payment.demo
      }));
    }
    const rec = seats.map(function (s, i) { return { tripId: tripId, seat: s, userId: me.id, ticketId: tickets[i].id }; });
    M.core.store.set('bookings', M.core.store.get('bookings', []).concat(rec));
    M.services.seats.release(tripId);
    return { ok: true, tickets: tickets };
  }
};
