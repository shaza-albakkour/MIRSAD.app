/* تنفيذ التنبيهات المجدولة عند حلول موعدها */
M.services.alertSchedules = {
  run: async function (once) {
    const U = M.utils.format, now = new Date(), hhmm = U.pad(now.getHours()) + ':' + U.pad(now.getMinutes());
    const due = M.services.schedules.list().filter(function (x) {
      return x.enabled && x.time === hhmm && x.days.indexOf(now.getDay()) >= 0;
    });
    for (const sc of due) {
      if (!M.services.settings.get().schedule || !once('sc:' + sc.id + U.isoDate(now), 600)) continue;
      await this.fire(sc);
    }
  },
  resolveStop: async function (sc) {
    if (sc.stopId && sc.stopId !== 'current') return sc.stopId;
    const loc = await M.services.gps.get();
    return loc.ok ? M.services.trackingQuery.nearestStop(loc.pos).stop.id : null;
  },
  message: function (sc, all) {
    const name = M.services.auth.current().name, mins = function (a) { return Math.max(1, Math.round(a.minutes)); };
    if (!all.length) return 'لا تتوفر بيانات تتبع للباصات القريبة حالياً';
    if (sc.kind === 'all') {
      return M.utils.greeting(name) + '، الباصات القادمة: ' +
        all.slice(0, 3).map(function (a) { return a.bus.code + ' خلال ' + mins(a) + ' د'; }).join('، ');
    }
    return M.utils.greeting(name) + '، يوجد باص زاجل قريب منك، متوقع وصوله خلال ' + mins(all[0]) + ' دقائق';
  },
  fire: async function (sc) {
    const stopId = await this.resolveStop(sc);
    if (!stopId) return;
    M.services.notifications.push({
      title: 'تنبيه مجدول', kind: 'schedule', link: '/internal/stop/' + stopId,
      body: this.message(sc, M.services.trackingQuery.arrivals(stopId))
    });
  }
};
