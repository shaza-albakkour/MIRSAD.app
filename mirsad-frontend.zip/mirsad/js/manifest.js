/* قائمة فهارس المجلدات بترتيب التحميل */
M.indexes = [
  'js/core/index.js',
  'assets/icons/index.js',
  'js/config/index.js',
  'js/utils/index.js',
  'js/data/index.js',
  'js/services/index.js',
  'js/components/index.js',
  'js/views/index.js',
  'js/app/index.js'
];
