/* المحمّل الرئيسي: يقرأ فهارس المجلدات ثم يحمّل كل الملفات بالترتيب */
(function () {
  const M = (window.M = { manifest: [] });
  M.files = function (dir, list) {
    list.forEach(function (f) { M.manifest.push(dir + '/' + f); });
  };
  function load(src) {
    return new Promise(function (ok, fail) {
      const s = document.createElement('script');
      s.src = src;
      s.onload = ok;
      s.onerror = function () { fail(new Error('تعذر تحميل: ' + src)); };
      document.body.appendChild(s);
    });
  }
  function sequence(list) {
    return list.reduce(function (p, src) {
      return p.then(function () { return load(src); });
    }, Promise.resolve());
  }
  load('js/manifest.js')
    .then(function () { return sequence(M.indexes); })
    .then(function () { return sequence(M.manifest); })
    .catch(function (e) {
      document.getElementById('screen').innerHTML =
        '<p style="padding:24px;font-family:sans-serif">خطأ في التحميل: ' + e.message + '</p>';
    });
})();
