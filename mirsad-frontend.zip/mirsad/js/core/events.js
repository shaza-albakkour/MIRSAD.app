/* ناقل أحداث بسيط بين الوحدات */
M.core.events = (function () {
  const handlers = {};
  return {
    on: function (name, fn) { (handlers[name] = handlers[name] || []).push(fn); },
    off: function (name, fn) {
      handlers[name] = (handlers[name] || []).filter(function (h) { return h !== fn; });
    },
    emit: function (name, data) {
      (handlers[name] || []).slice().forEach(function (fn) { fn(data); });
    }
  };
})();
