M.files('js/core', ['namespace.js', 'dom.js', 'store.js', 'events.js', 'router.js', 'routes.js']);
