/* جدول المسارات: كل مسار يربط عنواناً باسم واجهة */
(function () {
  const r = M.core.router.add;
  r('/login', 'login', { public: true });
  r('/register', 'register', { public: true });
  r('/otp', 'otp', { public: true });
  r('/forgot', 'forgot', { public: true });
  r('/home', 'home', { nav: 'home' });
  r('/notifications', 'notifications', { nav: 'home' });
  r('/internal', '', { redirect: '/internal/map' });
  r('/internal/stop/:id', 'stopDetail', { nav: 'internal' });
  r('/internal/:tab', 'internal', { nav: 'internal' });
  r('/external', 'externalSearch', { nav: 'external' });
  r('/external/results', 'externalResults', { nav: 'external' });
  r('/external/seats/:tripId', 'seats', { nav: 'external' });
  r('/external/checkout/:tripId', 'checkout', { nav: 'external' });
  r('/tickets', 'tickets', { nav: 'tickets' });
  r('/tickets/:id', 'ticket', { nav: 'tickets' });
  r('/complaints', 'complaints', { nav: 'profile' });
  r('/complaints/new', 'complaintNew', { nav: 'profile' });
  r('/complaints/:ref', 'complaintDetail', { nav: 'profile' });
  r('/profile', 'profile', { nav: 'profile' });
  r('/profile/:page', 'profilePage', { nav: 'profile' });
})();
