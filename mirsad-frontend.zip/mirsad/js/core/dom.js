/* أدوات DOM مشتركة */
M.core.dom = {
  qs: function (sel, root) { return (root || document).querySelector(sel); },
  qsa: function (sel, root) { return Array.from((root || document).querySelectorAll(sel)); },
  on: function (root, type, sel, fn) {
    root.addEventListener(type, function (e) {
      const t = e.target.closest(sel);
      if (t && root.contains(t)) fn(e, t);
    });
  },
  esc: function (v) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return map[c]; });
  },
  val: function (id, root) {
    const el = (root || document).querySelector('#' + id);
    return el ? el.value.trim() : '';
  }
};
