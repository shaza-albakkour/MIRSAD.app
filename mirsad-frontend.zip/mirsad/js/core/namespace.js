/* الحاويات الرئيسية لكل وحدات التطبيق */
['core', 'config', 'utils', 'data', 'services', 'components', 'views', 'icons'].forEach(function (k) {
  M[k] = M[k] || {};
});
