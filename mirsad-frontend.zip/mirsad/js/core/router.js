/* موجّه الصفحات المبني على hash */
M.core.router = (function () {
  const routes = [];
  let current = null;
  function compile(pattern) {
    const keys = [];
    const src = pattern.replace(/:(\w+)/g, function (_, k) { keys.push(k); return '([^/]+)'; });
    return { re: new RegExp('^' + src + '$'), keys: keys };
  }
  function add(pattern, view, opts) {
    routes.push(Object.assign({ pattern: pattern, view: view }, compile(pattern), opts || {}));
  }
  function path() { return location.hash.replace(/^#/, '') || '/home'; }
  function match(p) {
    for (const r of routes) {
      const m = r.re.exec(p);
      if (m) {
        const params = {};
        r.keys.forEach(function (k, i) { params[k] = decodeURIComponent(m[i + 1]); });
        return { route: r, params: params };
      }
    }
    return null;
  }
  function go(p) { location.hash = '#' + p; }
  function replace(p) { history.replaceState(null, '', '#' + p); render(); }
  function render() {
    const found = match(path()) || match('/home');
    const route = found.route;
    if (route.redirect) return replace(route.redirect);
    if (!route.public && !M.services.auth.isLoggedIn()) return replace(M.services.auth.entryRoute());
    if (current && current.unmount) current.unmount();
    const screen = document.getElementById('screen');
    current = M.views[route.view];
    screen.innerHTML = current.render(found.params);
    screen.scrollTop = 0;
    if (current.mount) current.mount(screen, found.params);
    M.components.nav.sync(route.nav, !route.public);
  }
  function start() { window.addEventListener('hashchange', render); render(); }
  return { add: add, go: go, replace: replace, render: render, start: start, path: path };
})();
