/* تخزين محلي آمن (يعالج الأخطاء ويستخدم بادئة خاصة بالتطبيق) */
M.core.store = {
  prefix: 'mirsad:',
  get: function (key, fallback) {
    try {
      const raw = localStorage.getItem(this.prefix + key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (e) { return fallback; }
  },
  set: function (key, value) {
    try { localStorage.setItem(this.prefix + key, JSON.stringify(value)); return true; }
    catch (e) { return false; }
  },
  remove: function (key) {
    try { localStorage.removeItem(this.prefix + key); } catch (e) { /* تجاهل */ }
  }
};
