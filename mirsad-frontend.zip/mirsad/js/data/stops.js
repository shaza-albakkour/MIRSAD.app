/* مواقف تجريبية في إدلب. استبدلها بالمواقف المعتمدة من الإدارة. */
M.data.stops = [
  { id: 's1', name: 'موقف المحطة المركزية', pos: [35.9306, 36.6339], demo: true },
  { id: 's2', name: 'موقف الساحة', pos: [35.9352, 36.6310], demo: true },
  { id: 's3', name: 'موقف المشفى', pos: [35.9410, 36.6385], demo: true },
  { id: 's4', name: 'موقف الجامعة', pos: [35.9468, 36.6452], demo: true },
  { id: 's5', name: 'موقف السوق', pos: [35.9285, 36.6270], demo: true },
  { id: 's6', name: 'موقف الحي الشرقي', pos: [35.9330, 36.6520], demo: true },
  { id: 's7', name: 'موقف الحي الغربي', pos: [35.9380, 36.6200], demo: true },
  { id: 's8', name: 'موقف المدخل الجنوبي', pos: [35.9195, 36.6340], demo: true }
];
M.data.stop = function (id) {
  return M.data.stops.find(function (s) { return s.id === id; });
};
