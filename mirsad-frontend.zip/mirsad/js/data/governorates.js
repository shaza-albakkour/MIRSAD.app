/* المحافظات السورية الأربع عشرة (إحداثيات مراكز المدن) */
M.data.governorates = [
  { id: 'idlib', name: 'إدلب', pos: [35.9306, 36.6339] },
  { id: 'damascus', name: 'دمشق', pos: [33.5138, 36.2765] },
  { id: 'rif-dimashq', name: 'ريف دمشق', pos: [33.5700, 36.4000] },
  { id: 'aleppo', name: 'حلب', pos: [36.2021, 37.1343] },
  { id: 'homs', name: 'حمص', pos: [34.7324, 36.7137] },
  { id: 'hama', name: 'حماة', pos: [35.1318, 36.7578] },
  { id: 'latakia', name: 'اللاذقية', pos: [35.5317, 35.7900] },
  { id: 'tartus', name: 'طرطوس', pos: [34.8890, 35.8866] },
  { id: 'daraa', name: 'درعا', pos: [32.6189, 36.1021] },
  { id: 'suwayda', name: 'السويداء', pos: [32.7090, 36.5662] },
  { id: 'quneitra', name: 'القنيطرة', pos: [33.1257, 35.8243] },
  { id: 'deir-ez-zor', name: 'دير الزور', pos: [35.3359, 40.1408] },
  { id: 'raqqa', name: 'الرقة', pos: [35.9528, 39.0079] },
  { id: 'hasakah', name: 'الحسكة', pos: [36.5024, 40.7477] }
];
M.data.governorate = function (id) {
  return M.data.governorates.find(function (g) { return g.id === id; });
};
