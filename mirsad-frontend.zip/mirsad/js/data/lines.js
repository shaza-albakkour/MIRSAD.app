/* خطوط سير تجريبية: كل خط دائري يمر بالمواقف بالترتيب */
M.data.lines = [
  { id: 'l1', name: 'خط ١ — المحطة ↔ الجامعة', color: '#14A38B', stops: ['s1', 's2', 's3', 's4'], demo: true },
  { id: 'l2', name: 'خط ٢ — السوق ↔ الحي الشرقي', color: '#F5A524', stops: ['s5', 's1', 's6'], demo: true },
  { id: 'l3', name: 'خط ٣ — الغربي ↔ الجنوبي', color: '#3B82F6', stops: ['s7', 's2', 's5', 's8'], demo: true }
];
M.data.line = function (id) {
  return M.data.lines.find(function (l) { return l.id === id; });
};
