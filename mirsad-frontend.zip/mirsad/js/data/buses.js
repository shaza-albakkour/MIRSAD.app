/* باصات تجريبية (حركتها محاكاة وليست GPS حقيقياً) */
M.data.buses = [
  { id: 'b1', code: 'ز-101', line: 'l1', offset: 0, speedKmh: 24, demo: true },
  { id: 'b2', code: 'ز-102', line: 'l1', offset: 0.5, speedKmh: 22, demo: true },
  { id: 'b3', code: 'ز-201', line: 'l2', offset: 0.2, speedKmh: 26, demo: true },
  { id: 'b4', code: 'ز-301', line: 'l3', offset: 0.1, speedKmh: 23, demo: true },
  { id: 'b5', code: 'ز-302', line: 'l3', offset: 0.6, speedKmh: 25, demo: true }
];
