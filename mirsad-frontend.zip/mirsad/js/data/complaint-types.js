M.data.complaintTypes = [
  'تأخر الباص', 'سلوك السائق', 'مشكلة في الحجز', 'مشكلة في الدفع',
  'نظافة الباص', 'مشكلة في التطبيق', 'اقتراح', 'أخرى'
];
M.data.complaintStatuses = {
  new: 'جديدة', review: 'قيد المراجعة', processing: 'قيد المعالجة', replied: 'تم الرد', closed: 'مغلقة'
};
