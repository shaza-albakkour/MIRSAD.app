/* حالة الخدمات الخارجية: demo = بيانات تجريبية، live = مرتبطة فعلياً.
   لا تغيّر أي قيمة إلى live قبل ربط الخدمة واختبارها. */
M.config.providers = {
  tracking: { mode: 'demo', label: 'تتبع الباصات' },
  otp: { mode: 'demo', label: 'رسائل التحقق OTP' },
  payment: { mode: 'demo', label: 'شام كاش' },
  push: { mode: 'browser', label: 'الإشعارات' },
  maps: { mode: 'live', label: 'الخرائط (OpenStreetMap)' },
  backend: { mode: 'demo', label: 'الخادم وقاعدة البيانات' }
};
M.config.isDemo = function (name) {
  return M.config.providers[name].mode === 'demo';
};
