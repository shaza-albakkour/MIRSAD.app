M.files('js/config', ['app-config.js', 'providers.js']);
