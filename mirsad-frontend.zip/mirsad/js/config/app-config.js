/* إعدادات التطبيق العامة: عدّل القيم هنا فقط */
M.config.app = {
  name: 'مِرصاد',
  company: 'الزاجل للنقل',
  currency: 'ل.س',
  mapCenter: [35.9306, 36.6339],
  mapZoom: 13,
  waiting: { radiusMeters: 150, ttlMinutes: 20 },
  boarding: { arriveEarlyMinutes: 5 },
  booking: { seatHoldMinutes: 5, seatsPerRow: 4, rows: 11 },
  alerts: { defaultRadiusKm: 1, checkEverySeconds: 20, minGapMinutes: 5 },
  pricePerKm: 120
};
