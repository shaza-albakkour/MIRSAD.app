/* تجزئة SHA-256 (ملاحظة: الحماية الحقيقية للحسابات تتم في الخادم) */
M.utils.crypto = {
  sha256: async function (text) {
    if (!(window.crypto && crypto.subtle)) return M.utils.crypto.fallback(text);
    const data = new TextEncoder().encode(text);
    const buf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf))
      .map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  },
  fallback: function (text) {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); }
    return 'f' + (h >>> 0).toString(16);
  },
  random: function (bytes) {
    const arr = crypto.getRandomValues(new Uint8Array(bytes || 16));
    return Array.from(arr).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  }
};
