/* مولّد معرفات ورموز مرجعية */
M.utils.ids = {
  uid: function (prefix) { return (prefix || 'id') + '_' + M.utils.crypto.random(6); },
  ref: function (prefix) {
    const n = Math.floor(100000 + Math.random() * 900000);
    return prefix + '-' + new Date().getFullYear() + '-' + n;
  }
};
