/* تنسيق الأرقام والتواريخ بالعربية */
M.utils.format = {
  digits: function (v) {
    return String(v).replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
  },
  money: function (n) {
    return Math.round(n).toLocaleString('ar-SY') + ' ' + M.config.app.currency;
  },
  distance: function (m) {
    return m < 1000 ? Math.round(m) + ' م' : (m / 1000).toFixed(1) + ' كم';
  },
  minutes: function (min) {
    if (min < 1) return 'يصل الآن';
    if (min < 60) return Math.round(min) + ' د';
    return Math.floor(min / 60) + ' س ' + Math.round(min % 60) + ' د';
  },
  time: function (d) {
    return new Date(d).toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit', hour12: true });
  },
  date: function (d) {
    return new Date(d).toLocaleDateString('ar-SY', { weekday: 'long', day: 'numeric', month: 'long' });
  },
  pad: function (n) { return String(n).padStart(2, '0'); },
  isoDate: function (d) {
    d = d || new Date();
    return d.getFullYear() + '-' + this.pad(d.getMonth() + 1) + '-' + this.pad(d.getDate());
  }
};
