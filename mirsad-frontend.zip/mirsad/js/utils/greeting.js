/* تحية شخصية حسب التوقيت المحلي للجهاز */
M.utils.greeting = function (name, date) {
  const h = (date || new Date()).getHours();
  let text = 'مساء الخير';
  if (h >= 5 && h < 12) text = 'صباح الخير';
  else if (h >= 12 && h < 17) text = 'طاب يومك';
  return text + '، ' + name;
};
