/* التحقق من الأرقام السورية وتحديد المشغّل */
M.utils.phone = (function () {
  const operators = {
    '093': 'سيريتل', '098': 'سيريتل', '099': 'سيريتل',
    '094': 'MTN', '095': 'MTN', '096': 'MTN'
  };
  function normalize(raw) {
    let n = M.utils.format.digits(raw).replace(/[\s\-()]/g, '');
    n = n.replace(/^\+?00?963/, '0');
    if (/^9\d{8}$/.test(n)) n = '0' + n;
    return n;
  }
  function validate(raw) {
    const n = normalize(raw);
    if (!/^09\d{8}$/.test(n)) {
      return { valid: false, error: 'أدخل رقماً سورياً صحيحاً مثل 0933123456' };
    }
    const op = operators[n.slice(0, 3)];
    if (!op) return { valid: false, error: 'مقدّم الخدمة غير معروف لهذا الرقم' };
    return { valid: true, normalized: n, operator: op };
  }
  return { normalize: normalize, validate: validate };
})();
