M.files('js/utils', ['format.js', 'geo.js', 'greeting.js', 'phone-validator.js', 'crypto.js', 'ids.js']);
