/* نقطة تشغيل التطبيق: محرك التنبيهات ثم الموجّه */
(function () {
  M.services.alerts.start();
  M.core.router.start();
})();
