M.files('assets/icons', ['ui-icons.js', 'transport-icons.js', 'status-icons.js']);
